#!/usr/bin/env bash
# Removes KubeHeal. With --all it also removes k3s and the built images.
set -Eeuo pipefail
export KUBECONFIG="${KUBECONFIG:-/etc/rancher/k3s/k3s.yaml}"
kubectl delete -f "$(dirname "$0")/deploy/k8s/30-kubeheal.yaml" --ignore-not-found
kubectl delete -f "$(dirname "$0")/deploy/k8s/20-demo-apps.yaml" --ignore-not-found
kubectl delete -f "$(dirname "$0")/deploy/k8s/10-prometheus.yaml" --ignore-not-found
kubectl delete secret kubeheal-auth kubeheal-notify -n kubeheal-system --ignore-not-found
kubectl delete -f "$(dirname "$0")/deploy/k8s/00-namespaces.yaml" --ignore-not-found
if [[ "${1:-}" == "--all" ]]; then
  [[ -x /usr/local/bin/k3s-uninstall.sh ]] && sudo /usr/local/bin/k3s-uninstall.sh
  sudo docker rmi kubeheal/kubeheal:2.1.0 kubeheal/demo-app:2.1.0 2>/dev/null || true
fi
echo "KubeHeal removed."
