#!/usr/bin/env bash
# One-shot installer for a fresh Ubuntu 22.04/24.04 host (EC2 free-tier friendly: 2 vCPU, >=2 GB RAM).
# Installs k3s (lightweight Kubernetes), builds the two images, deploys Prometheus + demo apps + KubeHeal.
# Re-runnable: every step is idempotent.
#
# Optional env: KUBEHEAL_PASSWORD=...   dashboard password (default: random, printed once)
#               NOTIFY_WEBHOOK_URL=...  Slack-compatible webhook for incident alerts
#               K3S_VERSION=v1.31.4+k3s1  pin a k3s release
#               USE_EXISTING_CLUSTER=1  skip k3s; use the cluster kubectl already points at
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="2.1.0"
KH_IMG="kubeheal/kubeheal:${VERSION}"
DEMO_IMG="kubeheal/demo-app:${VERSION}"

log()  { printf '\n\033[1;34m[KubeHeal]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mWARN:\033[0m %s\n' "$*" >&2; }
fail() { printf '\033[1;31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }
trap 'fail "Step failed at line $LINENO. Run scripts/verify.sh for diagnostics."' ERR

[[ $EUID -ne 0 ]] || fail "Run as a normal user with sudo rights (not as root)."
command -v sudo >/dev/null || fail "sudo is required."
case "$(uname -m)" in x86_64|aarch64|arm64) ;; *) fail "Unsupported CPU architecture $(uname -m)";; esac

CPUS=$(nproc); MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
(( CPUS >= 2 )) || warn "Only ${CPUS} vCPU detected. 2 are recommended; expect slow recovery."
(( MEM_MB >= 1700 )) || warn "Only ${MEM_MB} MB RAM. 2 GB minimum (4 GB comfortable); swap will be added."

# ---------------------------------------------------------------- 1. swap
log "1/7 Ensuring swap (protects a small instance from OOM during builds)"
if [[ -z "$(swapon --show --noheadings)" ]]; then
  sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile >/dev/null && sudo swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
else
  echo "swap already present"
fi

# ---------------------------------------------------------------- 2. docker
log "2/7 Installing Docker (used only to build images)"
sudo apt-get update -y
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y docker.io curl ca-certificates
sudo systemctl enable --now docker

# ---------------------------------------------------------------- 3. k3s
if [[ "${USE_EXISTING_CLUSTER:-0}" != "1" ]]; then
  log "3/7 Installing k3s (traefik, servicelb and metrics-server disabled to save ~300 MB RAM)"
  if ! command -v k3s >/dev/null; then
    [[ -n "${K3S_VERSION:-}" ]] && export INSTALL_K3S_VERSION="$K3S_VERSION"
    curl -sfL https://get.k3s.io | \
      INSTALL_K3S_EXEC="server --disable traefik --disable servicelb --disable metrics-server --write-kubeconfig-mode 644" sh -
  else
    echo "k3s already installed"
  fi
  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
  mkdir -p "$HOME/.kube" && cp -f "$KUBECONFIG" "$HOME/.kube/config" && chmod 600 "$HOME/.kube/config"
else
  log "3/7 Using the existing cluster from your kubeconfig"
fi
command -v kubectl >/dev/null || fail "kubectl not found"
for i in $(seq 1 60); do
  kubectl get nodes 2>/dev/null | grep -qw Ready && break
  [[ $i -eq 60 ]] && fail "Node did not become Ready in 5 minutes"; sleep 5
done
kubectl get nodes

# ---------------------------------------------------------------- 4-5. images
log "4/7 Building images"
sudo docker build -q -t "$KH_IMG"   "$ROOT/services/kubeheal"
sudo docker build -q -t "$DEMO_IMG" "$ROOT/services/demo-app"

log "5/7 Loading images into the cluster's container runtime"
import_image() {
  if command -v k3s >/dev/null && [[ "${USE_EXISTING_CLUSTER:-0}" != "1" ]]; then
    sudo docker save "$1" | sudo k3s ctr images import - >/dev/null
  elif command -v minikube >/dev/null; then
    minikube image load "$1"
  elif command -v kind >/dev/null; then
    kind load docker-image "$1"
  else
    fail "Don't know how to load $1 into your cluster; push it to a registry and edit deploy/k8s/*.yaml"
  fi
}
import_image "$KH_IMG"; import_image "$DEMO_IMG"

# ---------------------------------------------------------------- 6. deploy
log "6/7 Deploying Prometheus, demo applications and KubeHeal"
kubectl apply -f "$ROOT/deploy/k8s/00-namespaces.yaml"

GENERATED=""
if [[ -n "${KUBEHEAL_PASSWORD:-}" ]] || ! kubectl -n kubeheal-system get secret kubeheal-auth >/dev/null 2>&1; then
  PASS="${KUBEHEAL_PASSWORD:-$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 14)}"
  kubectl -n kubeheal-system create secret generic kubeheal-auth --from-literal=password="$PASS" \
    --dry-run=client -o yaml | kubectl apply -f -
  [[ -z "${KUBEHEAL_PASSWORD:-}" ]] && GENERATED="$PASS"
fi

if [[ -n "${NOTIFY_WEBHOOK_URL:-}" ]]; then
  kubectl -n kubeheal-system create secret generic kubeheal-notify --from-literal=url="$NOTIFY_WEBHOOK_URL" \
    --dry-run=client -o yaml | kubectl apply -f -
fi

kubectl apply -f "$ROOT/deploy/k8s/10-prometheus.yaml"
kubectl apply -f "$ROOT/deploy/k8s/20-demo-apps.yaml"
kubectl apply -f "$ROOT/deploy/k8s/30-kubeheal.yaml"

for target in "monitoring prometheus" "kubeheal-demo frontend" "kubeheal-demo backend" "kubeheal-demo database" \
              "kubeheal-demo loadgen" "kubeheal-system kubeheal"; do
  set -- $target
  kubectl -n "$1" rollout status "deployment/$2" --timeout=300s
done

# ---------------------------------------------------------------- 7. summary
log "7/7 Done"
kubectl get pods -A --no-headers | grep -E 'monitoring|kubeheal' || true
TOKEN=$(curl -s -m2 -X PUT http://169.254.169.254/latest/api/token -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' || true)
IP=$(curl -s -m2 -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/public-ipv4 || true)
cat <<MSG

=====================================================================
 KubeGuard dashboard:   http://${IP:-<EC2-PUBLIC-IP>}:30080
   user: admin   password: ${GENERATED:-<unchanged; read it with the command below>}
   (read later: kubectl -n kubeheal-system get secret kubeheal-auth -o jsonpath='{.data.password}' | base64 -d)

 EC2 security group: allow TCP 30080 ONLY from your own IP.
 Safer still (no open port): ssh -L 8080:localhost:30080 ubuntu@<host>  then open http://localhost:8080

 Metrics need ~1 minute to appear. Verify the pipeline:  scripts/verify.sh
 Then open Experiments in the dashboard and trigger a fault.
=====================================================================
MSG
