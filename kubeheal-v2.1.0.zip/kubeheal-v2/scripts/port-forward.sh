#!/usr/bin/env bash
# Expose the in-cluster KubeGuard dashboard on http://localhost:8080 (default). Ctrl+C to stop.
#   PORT=9090 ./scripts/port-forward.sh
#   ADDRESS=0.0.0.0 ./scripts/port-forward.sh   # reachable from other machines: restrict the EC2 security group to your IP!
set -euo pipefail
export KUBECONFIG="${KUBECONFIG:-$HOME/.kube/config}"
PORT="${PORT:-8080}"; ADDRESS="${ADDRESS:-127.0.0.1}"
echo "KubeGuard -> http://${ADDRESS/0.0.0.0/<this-host>}:${PORT}   (user: admin, password: kubectl -n kubeheal-system get secret kubeheal-auth -o jsonpath='{.data.password}' | base64 -d)"
exec kubectl -n kubeheal-system port-forward --address "$ADDRESS" svc/kubeheal "${PORT}:8080"
