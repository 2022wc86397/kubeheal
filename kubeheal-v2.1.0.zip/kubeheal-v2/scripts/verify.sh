#!/usr/bin/env bash
# Diagnoses the monitoring pipeline end to end: pods -> Prometheus targets -> queries -> KubeHeal API.
set -uo pipefail
export KUBECONFIG="${KUBECONFIG:-$HOME/.kube/config}"
ok(){ printf '\033[32mOK  \033[0m %s\n' "$*"; }; bad(){ printf '\033[31mBAD \033[0m %s\n' "$*"; }

echo "== Pods"; kubectl get pods -A -o wide --no-headers | grep -E 'monitoring|kubeheal' || bad "no pods found"
echo; echo "== Not-ready pods"; kubectl get pods -A --no-headers | grep -E 'monitoring|kubeheal' | grep -v -E 'Running|Completed' || ok "none"

PROM="/api/v1/namespaces/monitoring/services/prometheus:9090/proxy"
echo; echo "== Prometheus scrape targets"
kubectl get --raw "$PROM/api/v1/targets" 2>/dev/null | python3 -c '
import sys, json
try: t = json.load(sys.stdin)["data"]["activeTargets"]
except Exception: print("BAD  Prometheus API not reachable"); sys.exit(0)
for job in sorted({x["labels"]["job"] for x in t}):
    up = [x for x in t if x["labels"]["job"] == job and x["health"] == "up"]
    all_ = [x for x in t if x["labels"]["job"] == job]
    print(("OK   " if up and len(up) == len(all_) else "BAD  ") + f"{job}: {len(up)}/{len(all_)} targets up")
    for x in all_:
        if x["health"] != "up": print("       ", x["scrapeUrl"], "->", x.get("lastError", "")[:120])
'
q(){ kubectl get --raw "$PROM/api/v1/query?query=$(python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))' "$1")" 2>/dev/null \
     | python3 -c 'import sys,json;r=json.load(sys.stdin)["data"]["result"];print(r[0]["value"][1] if r else "no data")' 2>/dev/null || echo "error"; }
echo; echo "== Key queries"
echo "node CPU %          : $(q '100 * sum(rate(container_cpu_usage_seconds_total{id="/"}[1m])) / sum(machine_cpu_cores)')"
echo "backend CPU cores   : $(q 'avg(sum by (pod) (rate(container_cpu_usage_seconds_total{namespace="kubeheal-demo",pod=~"backend-[a-z0-9]{8,10}-[a-z0-9]{5}",container!=""}[1m])))')"
echo "backend req/s       : $(q 'sum(rate(http_requests_total{namespace="kubeheal-demo",app="backend"}[1m]))')"

echo; echo "== KubeHeal API"
kubectl -n kubeheal-system exec deploy/kubeheal -- python -c '
import json, urllib.request
d = json.load(urllib.request.urlopen("http://localhost:8080/api/health"))
print("OK   health:", d)' 2>/dev/null || bad "KubeHeal not answering (kubectl -n kubeheal-system logs deploy/kubeheal)"
