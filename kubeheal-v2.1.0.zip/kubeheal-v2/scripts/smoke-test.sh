#!/usr/bin/env bash
# Live acceptance test: injects REAL faults through the API and waits for verified recoveries.
#   KUBEHEAL_URL=http://localhost:30080 KUBEHEAL_PASSWORD=... ./scripts/smoke-test.sh
# Exit code 0 only if every scenario ends with the incident in RECOVERED.
set -uo pipefail
URL="${KUBEHEAL_URL:-http://localhost:30080}"
PASS="${KUBEHEAL_PASSWORD:-$(kubectl -n kubeheal-system get secret kubeheal-auth -o jsonpath='{.data.password}' 2>/dev/null | base64 -d 2>/dev/null || true)}"
CURL=(curl -fsS -m 10); [[ -n "$PASS" ]] && CURL+=(-u "admin:$PASS")
j(){ python3 -c "import sys,json;d=json.load(sys.stdin);print($1)"; }
ok(){ printf '\033[32mPASS\033[0m %s\n' "$*"; }; bad(){ printf '\033[31mFAIL\033[0m %s\n' "$*"; FAILED=1; }
FAILED=0

"${CURL[@]}" "$URL/api/health" >/dev/null || { bad "KubeHeal not reachable at $URL"; exit 1; }
ok "dashboard reachable"
SETTINGS=$("${CURL[@]}" "$URL/api/settings"); SUSTAIN=$(echo "$SETTINGS" | j "int(d['sustain_seconds'])")

wait_incident() {   # $1=incident id, $2=timeout s  -> prints final status
  local end=$((SECONDS+$2)) st=ACTIVE
  while (( SECONDS < end )); do
    st=$("${CURL[@]}" "$URL/api/incidents/$1" | j "d['status']"); [[ "$st" != ACTIVE ]] && break; sleep 3
  done; echo "$st"
}

echo "-- Scenario 1: crash a frontend pod"
ID=$("${CURL[@]}" -X POST -H 'Content-Type: application/json' -d '{"application":"frontend"}' "$URL/api/experiments/crash" | j "d['incident']")
ST=$(wait_incident "$ID" 180)
[[ "$ST" == RECOVERED ]] && ok "incident #$ID recovered ($("${CURL[@]}" "$URL/api/incidents/$ID" | j "d['action']"))" || bad "incident #$ID ended $ST"

echo "-- Scenario 2: CPU stress on backend (needs ~${SUSTAIN}s sustained breach)"
BEFORE=$("${CURL[@]}" "$URL/api/incidents" | j "max([i['id'] for i in d['incidents']] or [0])")
"${CURL[@]}" -X POST -H 'Content-Type: application/json' -d '{"application":"backend","seconds":150}' "$URL/api/experiments/cpu" >/dev/null || bad "could not start CPU experiment"
CPU_ID=""; END=$((SECONDS+SUSTAIN+120))
while (( SECONDS < END )); do
  CPU_ID=$("${CURL[@]}" "$URL/api/incidents" | j "next((str(i['id']) for i in d['incidents'] if i['id']>$BEFORE and i['type']=='CPU_OVERLOAD'),'')")
  [[ -n "$CPU_ID" ]] && break; sleep 4
done
if [[ -z "$CPU_ID" ]]; then bad "no CPU_OVERLOAD incident detected (check scripts/verify.sh: is Prometheus scraping cAdvisor?)"
else
  ok "CPU_OVERLOAD detected as incident #$CPU_ID"
  ST=$(wait_incident "$CPU_ID" 180)
  [[ "$ST" == RECOVERED ]] && ok "incident #$CPU_ID recovered ($("${CURL[@]}" "$URL/api/incidents/$CPU_ID" | j "d['action']"))" || bad "incident #$CPU_ID ended $ST"
fi
"${CURL[@]}" -X POST -H 'Content-Type: application/json' -d '{}' "$URL/api/experiments/stop" >/dev/null
echo; (( FAILED )) && { echo "SMOKE TEST FAILED"; exit 1; } || { echo "SMOKE TEST PASSED"; exit 0; }
