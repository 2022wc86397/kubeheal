#!/usr/bin/env bash
# Starts the simulator with fast timings, runs the browser tests, stops the simulator.
set -euo pipefail
cd "$(dirname "$0")"
[[ -d node_modules ]] || npm install --silent
PORT="${PORT:-8097}"
rm -f /tmp/kubeheal-e2e.db*
( cd ../../services/kubeheal && KUBEHEAL_MODE=mock DB_PATH=/tmp/kubeheal-e2e.db MOCK_STARTUP_SECONDS=3 \
  DETECT_INTERVAL_SECONDS=2 VERIFY_POLL_SECONDS=1 python3 -c "
from app.main import create_app
create_app().run(port=$PORT, threaded=True)" >/tmp/kubeheal-e2e.log 2>&1 ) &
SERVER=$!
trap 'kill $SERVER 2>/dev/null || true' EXIT
for _ in $(seq 1 30); do curl -sf "localhost:$PORT/api/health" >/dev/null && break; sleep 0.5; done
BASE="http://localhost:$PORT" node ui.test.js
