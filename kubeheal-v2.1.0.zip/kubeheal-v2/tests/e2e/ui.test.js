/* End-to-end UI test in a real headless Chromium against a running KubeHeal (simulator or cluster).
 *   BASE=http://localhost:8080 node ui.test.js            (OUT=dir saves screenshots)
 * Needs the simulator's fast settings (see run-e2e.sh) because it waits for real detection + recovery.
 */
const puppeteer = require('puppeteer-core');
const BASE = process.env.BASE || 'http://localhost:8080';
const OUT = process.env.OUT || '';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const results = []; const problems = [];
const check = (name, ok, extra = '') => { results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`); };
const post = (p, b) => fetch(BASE + p, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(b || {})}).then(r => r.json());

async function until(fn, ms = 30000, step = 250) { const end = Date.now() + ms; while (Date.now() < end) { try { const v = await fn(); if (v) return v; } catch (_) {} await sleep(step); } return null; }

(async () => {
  let exe = process.env.CHROME_PATH;
  if (!exe) { const c = require('@sparticuz/chromium'); exe = await (c.default || c).executablePath(); var args = (c.default || c).args; }
  const browser = await puppeteer.launch({executablePath: exe, headless: 'shell', args: [...(args || []), '--no-sandbox']});
  const page = await browser.newPage();
  await page.setViewport({width: 1360, height: 900, deviceScaleFactor: 1.5});
  page.on('pageerror', e => problems.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') problems.push('console: ' + m.text()); });
  page.on('requestfailed', r => problems.push('request failed: ' + r.url()));
  const shot = async n => { if (OUT) await page.screenshot({path: `${OUT}/${n}.png`, fullPage: true}); };
  const go = async h => { await page.goto(`${BASE}/#/${h}`); await page.reload({waitUntil: 'networkidle0'}); await sleep(900); };
  const text = sel => page.$eval(sel, e => e.innerText).catch(() => '');

  // ---- fast detection for the test, clean slate for theme
  await post('/api/settings', {sustain_seconds: 5, cooldown_seconds: 5});
  await page.goto(BASE); await page.evaluate(() => localStorage.removeItem('kg-theme'));   // once: start in the default theme

  // ---- experiments page + active chip
  await go('experiments');
  check('experiment cards render', (await page.$$('.exp')).length === 4);
  await page.select('#xapp', 'backend'); await page.select('#xsec', '120');
  await page.click('[data-k="cpu"]');
  check('CPU stress shows active chip', !!(await until(async () => (await text('#xactive')).includes('CPU stress on backend'), 8000)));

  // ---- live banner + nav badge while incident is active
  await go('dashboard');
  const live = await until(() => page.$('.live'), 40000, 150);
  check('live recovery banner appears', !!live);
  check('sidebar badge shows active count', (await text('#nb')).trim() === '1');
  check('tab title shows active count', (await page.title()).startsWith('(1)'));
  await shot('01-dashboard-live');
  if (live) { await page.click('.live a'); await sleep(1200); }
  check('live incident detail with elapsed timer', /elapsed/.test(await text('#main')) && /Recovery Progress/.test(await text('#main')));
  await shot('02-incident-live');

  // ---- recovery completes; toast announced
  const toastSeen = await until(async () => /recovered/i.test(await text('#toast')), 45000, 200);
  check('toast announces recovery', !!toastSeen);
  const recovered = await until(async () => /Recovered/.test(await text('#main')), 30000);
  check('incident detail ends Recovered', !!recovered);
  await shot('03-incident-recovered');
  await post('/api/experiments/stop', {application: 'backend'});

  // ---- incidents list: summary + CSV
  await go('incidents');
  await until(async () => /Mean time/.test(await text('#strip')), 8000);
  const strip = await text('#strip');
  check('summary strip has MTTR + success rate', /Mean time to recovery/.test(strip) && /100%/.test(strip), strip);
  const csv = await page.$eval('a[download]', a => a.getAttribute('href'));
  check('CSV export link present', csv === '/api/incidents.csv');
  const csvText = await (await fetch(BASE + csv)).text();
  check('CSV contains the incident', /backend,CPU_OVERLOAD,High,RECOVERED/.test(csvText), csvText.slice(0, 200));
  await shot('04-incidents');

  // ---- metrics: markers, threshold, tooltip
  await go('metrics/backend');
  await until(() => page.$('#c-cpu svg'), 8000);
  check('incident marker on CPU chart', !!(await page.$('#c-cpu a[href^="#/incidents/"]')));
  check('threshold label on CPU chart', /critical 90%/.test(await page.$eval('#c-cpu', e => e.innerHTML)));
  const box = await (await page.$('#c-cpu svg')).boundingBox();
  await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5); await sleep(300);
  const tip = await page.$eval('#c-cpu .tip', e => ({d: getComputedStyle(e).display, t: e.innerText}));
  check('hover tooltip shows time + value', tip.d === 'block' && /CPU: \d/.test(tip.t), JSON.stringify(tip));
  await shot('05-metrics-tooltip');

  // ---- pods mini bars
  await go('pods'); await until(() => page.$('.minibar'), 8000);
  check('pod rows show usage bars', (await page.$$('.minibar')).length > 0);

  // ---- settings reset
  await go('settings');
  await page.$eval('#s_cpu_critical', e => e.value = '75');
  page.once('dialog', d => d.accept());
  await page.click('#reset'); await sleep(1200);
  check('settings reset restores defaults', (await page.$eval('#s_cpu_critical', e => e.value)) === '90');
  await post('/api/settings', {sustain_seconds: 5, cooldown_seconds: 5});

  // ---- dark mode toggle + persistence
  await go('dashboard');
  const bgLight = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await page.click('#theme'); await sleep(300);
  const bgDark = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  check('dark mode changes the theme', bgLight !== bgDark && (await page.evaluate(() => document.documentElement.dataset.theme)) === 'dark');
  await page.reload({waitUntil: 'networkidle0'}); await sleep(900);
  check('theme persists across reload', (await page.evaluate(() => document.documentElement.dataset.theme)) === 'dark');
  await shot('06-dashboard-dark');
  await go('experiments'); await shot('07-experiments-dark');
  await go('metrics/backend'); await sleep(800); await shot('08-metrics-dark');
  await page.click('#theme');

  // ---- responsive: no horizontal overflow on any route at phone width
  await page.setViewport({width: 390, height: 844, deviceScaleFactor: 2, isMobile: true});
  for (const r of ['dashboard', 'applications', 'pods', 'incidents', 'experiments', 'metrics/backend', 'settings']) {
    await go(r);
    const over = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    check(`no horizontal overflow on mobile: ${r}`, over <= 1, `overflow ${over}px`);
    if (r === 'dashboard') await shot('09-mobile-dashboard');
    if (r === 'experiments') await shot('10-mobile-experiments');
  }

  check('no JS errors / failed requests', problems.length === 0, '\n   ' + problems.join('\n   '));
  await browser.close();
  const failed = results.filter(x => !x).length;
  console.log(`\n${results.length - failed}/${results.length} checks passed`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('E2E crashed:', e); process.exit(2); });
