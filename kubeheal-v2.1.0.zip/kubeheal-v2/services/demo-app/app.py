"""Demo workload with real, controllable faults and Prometheus metrics (no extra dependencies).

Endpoints
  GET  /              simulated request (latency ~ BASE_LATENCY_MS), counted in metrics
  GET  /healthz       liveness/readiness (never affected by chaos)
  GET  /metrics       Prometheus exposition
  POST /chaos/cpu?seconds=N              burn CPU (limited by the pod's CPU limit)
  POST /chaos/memory?seconds=N&percent=P allocate memory up to P% of the container limit
  POST /chaos/errors?seconds=N&rate=R    answer fraction R of requests with HTTP 500
  POST /chaos/stop                       end all faults
  GET  /chaos/status
"""
import gc
import os
import random
import socket
import threading
import time

from flask import Flask, jsonify, request

APP_NAME = os.getenv("APP_NAME", "demo")
BASE_LATENCY_MS = float(os.getenv("BASE_LATENCY_MS", "40"))
INFRA = ("/healthz", "/metrics", "/chaos")
BUCKETS = (0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0)

app = Flask(__name__)
_lock = threading.Lock()
_requests = {}                                   # status code -> count
_hist = [0] * len(BUCKETS)
_hist_sum, _hist_count = 0.0, 0
_chaos = {"cpu_until": 0.0, "mem_until": 0.0, "err_until": 0.0, "err_rate": 0.0}
_ballast = []


# ------------------------------------------------------------------ chaos
def _cgroup_read(*paths):
    for p in paths:
        try:
            with open(p) as f:
                v = f.read().strip()
            if v and v != "max":
                return int(v)
        except (OSError, ValueError):
            continue
    return None


def _mem_limit():
    return _cgroup_read("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes") \
        or int(os.getenv("MEM_LIMIT_MB", "192")) * 1048576


def _mem_current():
    return _cgroup_read("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory/memory.usage_in_bytes") or 0


def _burn_cpu():
    while time.time() < _chaos["cpu_until"]:
        sum(i * i for i in range(20000))         # busy work; the cgroup limit throttles it


def _hold_memory(percent):
    target = _mem_limit() * percent / 100.0
    chunk = 4 * 1048576
    while time.time() < _chaos["mem_until"] and _mem_current() < target:
        _ballast.append(bytearray(b"\x01") * chunk)     # writing touches every page
        time.sleep(0.02)
    while time.time() < _chaos["mem_until"]:
        time.sleep(0.5)
    _ballast.clear()
    gc.collect()


def _seconds():
    return min(max(float(request.args.get("seconds", 60)), 1), 900)


@app.post("/chaos/cpu")
def chaos_cpu():
    _chaos["cpu_until"] = time.time() + _seconds()
    threading.Thread(target=_burn_cpu, daemon=True).start()
    return jsonify(ok=True, fault="cpu", pod=socket.gethostname())


@app.post("/chaos/memory")
def chaos_memory():
    _chaos["mem_until"] = time.time() + _seconds()
    pct = min(max(float(request.args.get("percent", 93)), 10), 96)   # never reach 100%: avoid OOM kill
    threading.Thread(target=_hold_memory, args=(pct,), daemon=True).start()
    return jsonify(ok=True, fault="memory", percent=pct, pod=socket.gethostname())


@app.post("/chaos/errors")
def chaos_errors():
    _chaos["err_until"] = time.time() + _seconds()
    _chaos["err_rate"] = min(max(float(request.args.get("rate", 0.6)), 0.0), 1.0)
    return jsonify(ok=True, fault="errors", rate=_chaos["err_rate"], pod=socket.gethostname())


@app.post("/chaos/stop")
def chaos_stop():
    for k in ("cpu_until", "mem_until", "err_until"):
        _chaos[k] = 0.0
    return jsonify(ok=True)


@app.get("/chaos/status")
def chaos_status():
    now = time.time()
    return jsonify({k: max(0, round(_chaos[k] - now)) for k in ("cpu_until", "mem_until", "err_until")})


# ---------------------------------------------------------------- traffic
@app.before_request
def _maybe_fail():
    request._t0 = time.perf_counter()
    if request.path.startswith(INFRA):
        return None
    if time.time() < _chaos["err_until"] and random.random() < _chaos["err_rate"]:
        return jsonify(error="injected failure", app=APP_NAME), 500
    return None


@app.after_request
def _record(resp):
    global _hist_sum, _hist_count
    if request.path.startswith(INFRA):
        return resp
    dt = time.perf_counter() - getattr(request, "_t0", time.perf_counter())
    with _lock:
        _requests[resp.status_code] = _requests.get(resp.status_code, 0) + 1
        _hist_sum += dt
        _hist_count += 1
        for i, b in enumerate(BUCKETS):
            if dt <= b:
                _hist[i] += 1
    return resp


@app.get("/")
def index():
    time.sleep(max(0.0, random.gauss(BASE_LATENCY_MS, BASE_LATENCY_MS * 0.25)) / 1000)
    return jsonify(app=APP_NAME, pod=socket.gethostname(), ok=True)


@app.get("/healthz")
def healthz():
    return "ok"


@app.get("/metrics")
def metrics():
    lines = ["# TYPE http_requests_total counter"]
    with _lock:
        for code, n in sorted(_requests.items()):
            lines.append(f'http_requests_total{{code="{code}"}} {n}')
        lines.append("# TYPE http_request_duration_seconds histogram")
        cum = 0
        for b, n in zip(BUCKETS, _hist):
            cum += n
            lines.append(f'http_request_duration_seconds_bucket{{le="{b}"}} {cum}')
        lines.append(f'http_request_duration_seconds_bucket{{le="+Inf"}} {_hist_count}')
        lines.append(f"http_request_duration_seconds_sum {_hist_sum}")
        lines.append(f"http_request_duration_seconds_count {_hist_count}")
    return "\n".join(lines) + "\n", 200, {"Content-Type": "text/plain; version=0.0.4"}
