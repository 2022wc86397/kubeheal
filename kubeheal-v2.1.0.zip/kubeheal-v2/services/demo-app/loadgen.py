"""Tiny steady traffic generator so request-rate, latency and error metrics always have data."""
import os
import threading
import time
import urllib.request

TARGETS = [t for t in os.getenv("TARGETS", "").split(",") if t]
RPS = float(os.getenv("RPS", "2"))


def hammer(url):
    while True:
        try:
            urllib.request.urlopen(url, timeout=5).read()
        except Exception:
            pass                                    # 5xx / timeouts are exactly what we want to observe
        time.sleep(1.0 / RPS)


if __name__ == "__main__":
    for t in TARGETS:
        threading.Thread(target=hammer, args=(t,), daemon=True).start()
    while True:
        time.sleep(3600)
