"""Fault-injection experiments. They create real faults; detection and recovery are not faked."""
import logging
import time

import requests

from .models import INCIDENT_TYPES
from .recovery import snapshot

log = logging.getLogger("kubeheal.experiments")

KINDS = {"crash", "cpu", "memory", "errors"}


class ExperimentError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def http_chaos(port):
    """Chaos transport for real clusters: POST /chaos/<kind> on the pod IP."""
    def send(pod, kind, params):
        if not pod.ip:
            return False
        try:
            r = requests.post(f"http://{pod.ip}:{port}/chaos/{kind}", params=params, timeout=4)
            return r.ok
        except requests.RequestException as exc:
            log.warning("chaos call to %s failed: %s", pod.name, exc)
            return False
    return send


class Experiments:
    def __init__(self, cluster, recovery, chaos, metrics=None):
        self.cluster, self.recovery, self.chaos = cluster, recovery, chaos
        self.metrics = metrics
        self._active = {}                     # (app, kind) -> epoch when the fault ends

    def _targets(self, app):
        if app not in {a.name for a in self.cluster.list_apps()}:
            raise ExperimentError(f"'{app}' is not a monitored application", 404)
        return [p for p in self.cluster.list_pods(app) if p.ready]

    def run(self, kind, app, seconds=90):
        if kind not in KINDS:
            raise ExperimentError(f"Unknown experiment '{kind}'", 404)
        seconds = int(min(max(seconds, 10), 600))
        pods = self._targets(app)
        if not pods:
            raise ExperimentError(f"No ready pods for '{app}'", 409)
        if self.recovery.is_busy(app):
            raise ExperimentError(f"A recovery is already running for '{app}'", 409)

        if kind == "crash":
            a = self.cluster.get_app(app)
            victim = pods[0]
            try:
                m = self.metrics.app_metrics(a) if self.metrics else {}
            except Exception:        # metrics are context only; never block the experiment
                m = {}
            before = snapshot(a, m)
            self.cluster.delete_pod(victim.name, grace=0)
            iid = self.recovery.start(app, "POD_FAILURE", "High",
                                      f"Pod {victim.name} was deleted (experiment)", before, source="experiment")
            return {"ok": True, "incident": iid, "message": f"Deleted pod {victim.name}"}

        params = {"cpu": {"seconds": seconds},
                  "memory": {"seconds": seconds, "percent": 93},
                  "errors": {"seconds": seconds, "rate": 0.6}}[kind]
        hit = sum(1 for p in pods if self.chaos(p, kind, params))
        if not hit:
            raise ExperimentError(f"No pod of '{app}' accepted the {kind} experiment. "
                                  "Only apps built from the demo-app image support it.", 422)
        self._active[(app, kind)] = time.time() + seconds
        self.cluster_log(app, f"Experiment '{kind}' started on {hit}/{len(pods)} pods for {seconds}s")
        label = INCIDENT_TYPES["CPU_OVERLOAD" if kind == "cpu" else "MEMORY_PRESSURE" if kind == "memory"
                               else "HIGH_ERROR_RATE"]
        return {"ok": True, "pods": hit, "message":
                f"{kind} fault injected into {hit} pod(s) for {seconds}s. Expect a '{label}' incident "
                "once the breach is sustained."}

    def active(self):
        now = time.time()
        self._active = {k: t for k, t in self._active.items() if t > now}
        return [{"application": a, "kind": k, "seconds_left": round(t - now)} for (a, k), t in sorted(self._active.items())]

    def stop(self, app=None):
        names = [app] if app else [a.name for a in self.cluster.list_apps()]
        stopped = 0
        for n in names:
            for p in self.cluster.list_pods(n):
                if p.ready and self.chaos(p, "stop", {}):
                    stopped += 1
        self._active = {k: t for k, t in self._active.items() if app and k[0] != app}
        return {"ok": True, "pods": stopped}

    def cluster_log(self, app, msg):
        log.info("%s: %s", app, msg)
        store = getattr(self.recovery, "store", None)
        if store:
            store.log_event(app, msg, "info")
