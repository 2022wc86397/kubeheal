"""Recovery engine: runs one remediation per application, verifies it, records the timeline."""
import logging
import threading
import time

from .models import INCIDENT_TYPES

log = logging.getLogger("kubeheal.recovery")

STEPS = [("detected", "Incident Detected"), ("classified", "Classifying Incident"),
         ("executing", "Executing Recovery Action"), ("verifying", "Verifying Recovery"),
         ("completed", "Completed")]

STRATEGY = {
    "POD_FAILURE": "Self-heal, then restart unhealthy pods, then restart the deployment",
    "CPU_OVERLOAD": "Scale out replicas (bounded by max replicas)",
    "MEMORY_PRESSURE": "Rolling restart of the deployment",
    "HIGH_ERROR_RATE": "Rolling restart of the deployment",
}


class Recovery:
    def __init__(self, cluster, metrics, store, poll=3.0, clock=time.time, sleep=time.sleep, notifier=None):
        self.cluster, self.metrics, self.store = cluster, metrics, store
        self.notifier = notifier
        self.poll, self.clock, self.sleep = poll, clock, sleep
        self._busy = {}
        self._lock = threading.Lock()

    # ---- public ---------------------------------------------------------
    def is_busy(self, app):
        with self._lock:
            return app in self._busy

    def start(self, app, typ, severity, description, before, source="auto"):
        """Open an incident and run recovery in the background. None if the app is already busy."""
        with self._lock:
            if app in self._busy:
                return None
            steps = [{"key": k, "label": lbl, "state": "pending", "detail": None, "ts": None}
                     for k, lbl in STEPS]
            iid = self.store.create_incident(app, typ, severity, description, before,
                                             source=source, steps=steps)
            self._busy[app] = iid
        self.store.log_event(app, f"Incident #{iid} opened: {INCIDENT_TYPES.get(typ, typ)}", "warn")
        self._notify("opened", iid)
        threading.Thread(target=self._run, args=(iid, app, typ, steps), daemon=True,
                         name=f"recovery-{iid}").start()
        return iid

    def _notify(self, kind, iid):
        if self.notifier and self.notifier.enabled:
            inc = self.store.get_incident(iid)
            inc["type_label"] = INCIDENT_TYPES.get(inc["type"], inc["type"])
            self.notifier.send(kind, inc)

    # ---- timeline helpers ----------------------------------------------
    def _step(self, iid, steps, key, state, detail=None):
        for s in steps:
            if s["key"] == key:
                s["state"] = state
                s["ts"] = self.clock()
                if detail is not None:
                    s["detail"] = detail
        self.store.update_incident(iid, steps=steps)

    # ---- main flow ------------------------------------------------------
    def _run(self, iid, app, typ, steps):
        t0 = self.store.get_incident(iid)["detected_at"]
        try:
            st = self.store.get_settings()
            self._step(iid, steps, "detected", "done")
            self._step(iid, steps, "classified", "done",
                       f"{INCIDENT_TYPES.get(typ, typ)}. Plan: {STRATEGY.get(typ, 'observe')}")
            self._step(iid, steps, "executing", "active")
            action, detail = self._execute(iid, app, typ, st)
            self.store.update_incident(iid, action=action)
            self._step(iid, steps, "executing", "done", detail)
            self._step(iid, steps, "verifying", "active", "Waiting for metrics to stabilise")
            ok = self._verify(iid, app, typ, st)
            now = self.clock()
            if ok:
                self._step(iid, steps, "verifying", "done", "Application is healthy again")
                self._step(iid, steps, "completed", "done")
                self.store.update_incident(iid, status="RECOVERED", resolved_at=now,
                                           recovery_seconds=round(now - t0, 1))
                self.store.log_event(app, f"Incident #{iid} recovered in {now - t0:.1f}s ({action})", "ok")
                self._notify("recovered", iid)
            else:
                self._step(iid, steps, "verifying", "failed",
                           f"Not recovered after {st['verify_timeout']:.0f}s. Manual attention required")
                self.store.update_incident(iid, status="FAILED", resolved_at=now,
                                           recovery_seconds=round(now - t0, 1))
                self.store.log_event(app, f"Incident #{iid} FAILED to recover", "error")
                self._notify("failed", iid)
        except Exception as exc:
            log.exception("recovery %s crashed", iid)
            self.store.update_incident(iid, status="FAILED", resolved_at=self.clock(),
                                       description=f"Recovery error: {exc}")
            self.store.log_event(app, f"Incident #{iid} aborted: {exc}", "error")
        finally:
            with self._lock:
                self._busy.pop(app, None)

    # ---- actions --------------------------------------------------------
    def _wait_ready(self, app, seconds):
        end = self.clock() + seconds
        while True:
            a = self.cluster.get_app(app)
            if a.desired > 0 and a.ready == a.desired:
                return True
            if self.clock() >= end:
                return False
            self.sleep(min(self.poll, 1.0))

    def _execute(self, iid, app, typ, st):
        """Returns (action label, human detail)."""
        if not st["auto_recovery"]:
            return "Observe only", "Auto-recovery is disabled in Settings; no action taken"

        if typ == "POD_FAILURE":
            if self._wait_ready(app, st["self_heal_grace"]):
                return "Kubernetes self-heal", "Deployment controller replaced the failed pod"
            bad = [p for p in self.cluster.list_pods(app) if not p.ready]
            for p in bad:
                self.cluster.delete_pod(p.name, grace=0)
            if bad and self._wait_ready(app, max(st["self_heal_grace"], 20)):
                return "Restart Pods", f"Deleted {len(bad)} unhealthy pod(s); controller replaced them"
            self.cluster.rolling_restart(app)
            return "Restart Deployment", "Pods stayed unhealthy; performed a rolling restart"

        if typ == "CPU_OVERLOAD":
            a = self.cluster.get_app(app)
            target = min(a.desired + 1, int(st["max_replicas"]))
            if target > a.desired:
                self.cluster.scale(app, target)
                return "Scale Replicas", f"Scaling replicas from {a.desired} to {target}"
            return "Observe only", f"Already at max replicas ({a.desired}); waiting for load to drop"

        if typ in ("MEMORY_PRESSURE", "HIGH_ERROR_RATE"):
            self.cluster.rolling_restart(app)
            return "Restart Deployment", "Rolling restart: pods are replaced one at a time"

        return "Observe only", "No strategy for this incident type"

    # ---- verification ---------------------------------------------------
    def _recovered(self, a, m, typ, st):
        if not a.rollout_complete:
            return False
        if typ == "CPU_OVERLOAD":
            return m.get("cpu_pct") is not None and m["cpu_pct"] < st["cpu_critical"]
        if typ == "MEMORY_PRESSURE":
            return m.get("mem_pct") is not None and m["mem_pct"] < st["memory_critical"]
        if typ == "HIGH_ERROR_RATE":
            return m.get("err_pct") is not None and m["err_pct"] < st["error_rate_critical"]
        return True                                      # POD_FAILURE: all replicas ready

    def _verify(self, iid, app, typ, st):
        end, streak = self.clock() + st["verify_timeout"], 0
        while self.clock() < end:
            a = self.cluster.get_app(app)
            m = self.metrics.app_metrics(a)
            self.store.update_incident(iid, after=snapshot(a, m))
            streak = streak + 1 if self._recovered(a, m, typ, st) else 0
            if streak >= 2:                              # two consecutive good readings
                return True
            self.sleep(self.poll)
        return False


def snapshot(a, m):
    """Compact metrics snapshot stored as 'before' / 'after' on an incident."""
    def r(v, n=1):
        return None if v is None else round(v, n)
    return {"cpu_pct": r(m.get("cpu_pct")), "mem_pct": r(m.get("mem_pct")),
            "resp_ms": r(m.get("resp_ms"), 0), "err_pct": r(m.get("err_pct"), 2),
            "ready": a.ready, "desired": a.desired, "ts": time.time()}
