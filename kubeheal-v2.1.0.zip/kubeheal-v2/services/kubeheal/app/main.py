"""Flask application: REST API + static dashboard. Start with: gunicorn 'app.main:create_app()'."""
import csv
import hmac
import io
import logging
import os
from types import SimpleNamespace

from flask import Flask, Response, jsonify, request, send_from_directory

from . import __version__
from .config import Config
from .db import DEFAULT_SETTINGS, Store
from .experiments import Experiments, ExperimentError, http_chaos
from .models import INCIDENT_TYPES
from .monitor import Monitor
from .notify import Notifier
from .recovery import Recovery

log = logging.getLogger("kubeheal")
RANGES = {"15m": 900, "1h": 3600, "3h": 10800, "6h": 21600}
STATIC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")


def build_runtime(cfg):
    store = Store(cfg.db_path)
    store.close_stale()
    if cfg.mode == "mock":
        from .mock import MockWorld
        world = MockWorld(startup=cfg.mock_startup)
        world.start_sampler()
        cluster = metrics = world
        chaos = world.apply_chaos
    else:
        from .k8s import KubeCluster
        from .prom import PromMetrics
        cluster = KubeCluster(cfg.namespace)
        metrics = PromMetrics(cfg.prometheus_url, cfg.namespace)
        chaos = http_chaos(cfg.chaos_port)
    recovery = Recovery(cluster, metrics, store, poll=cfg.verify_poll, notifier=Notifier(cfg.notify_webhook))
    monitor = Monitor(cluster, metrics, store, recovery, interval=cfg.interval)
    experiments = Experiments(cluster, recovery, chaos, metrics)
    return SimpleNamespace(cfg=cfg, store=store, cluster=cluster, metrics=metrics,
                           recovery=recovery, monitor=monitor, experiments=experiments)


def _incident_out(i):
    i["type_label"] = INCIDENT_TYPES.get(i["type"], i["type"])
    return i


def create_app(cfg=None, runtime=None, start_threads=True):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = cfg or Config()
    rt = runtime or build_runtime(cfg)
    app = Flask(__name__, static_folder=None)
    app.rt = rt
    if start_threads:
        rt.monitor.start()

    # ---- optional HTTP basic auth ---------------------------------------
    @app.before_request
    def guard():
        if not cfg.auth_password or request.path == "/api/health":
            return None
        a = request.authorization
        if a and hmac.compare_digest(a.username or "", cfg.auth_user) \
                and hmac.compare_digest(a.password or "", cfg.auth_password):
            return None
        return Response("Authentication required", 401, {"WWW-Authenticate": 'Basic realm="KubeHeal"'})

    @app.after_request
    def no_cache(resp):
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ---- static ---------------------------------------------------------
    @app.get("/")
    def index():
        return send_from_directory(STATIC, "index.html")

    @app.get("/static/<path:name>")
    def static_files(name):
        return send_from_directory(STATIC, name)

    # ---- meta -----------------------------------------------------------
    @app.get("/api/health")
    def health():
        return jsonify(status="ok", version=__version__)

    @app.get("/api/ready")
    def ready():
        ok = rt.monitor.ticks > 0
        return jsonify(ready=ok), (200 if ok else 503)

    @app.get("/api/config")
    def config():
        return jsonify(brand=cfg.brand, namespace=cfg.namespace, mode=cfg.mode, version=__version__,
                       notifications=bool(cfg.notify_webhook), auth=bool(cfg.auth_password))

    # ---- overview -------------------------------------------------------
    @app.get("/api/overview")
    def overview():
        snap = rt.monitor.snapshot
        apps_, pods = snap["apps"], snap["pods"]
        count = lambda s: sum(1 for a in apps_ if a["status"] == s)
        counts = {"applications": len(apps_), "healthy": count("healthy"), "warning": count("warning"),
                  "critical": count("critical") + count("stopped"),
                  "pods": len(pods), "running": sum(1 for p in pods if p["ready"]),
                  "not_ready": sum(1 for p in pods if not p["ready"]), **rt.store.counts()}
        import time as _time
        return jsonify(ts=snap["ts"], now=_time.time(), cluster_connected=snap["cluster_connected"], error=snap.get("error"),
                       prometheus_ok=snap.get("prometheus_ok", False), counts=counts,
                       cluster=snap.get("cluster", {}), apps=apps_, events=rt.store.list_events(8),
                       active_incidents=[_incident_out(i) for i in rt.store.list_incidents("ACTIVE")])

    @app.get("/api/apps")
    def list_apps():
        return jsonify(apps=rt.monitor.snapshot["apps"])

    @app.get("/api/pods")
    def list_pods():
        pods = rt.monitor.snapshot["pods"]
        name = request.args.get("app")
        return jsonify(pods=[p for p in pods if not name or p["app"] == name])

    @app.post("/api/pods/<name>/delete")
    def delete_pod(name):
        if name not in {p["name"] for p in rt.monitor.snapshot["pods"]}:
            return jsonify(ok=False, message="Unknown pod"), 404
        rt.cluster.delete_pod(name, grace=30)
        rt.store.log_event(None, f"Pod {name} deleted manually (restart)", "info")
        return jsonify(ok=True)

    # ---- application onboarding ----------------------------------------
    @app.get("/api/candidates")
    def candidates():
        return jsonify(candidates=rt.cluster.candidates())

    @app.post("/api/apps")
    def add_app():
        name = (request.get_json(silent=True) or {}).get("name", "")
        if name not in rt.cluster.candidates():
            return jsonify(ok=False, message=f"'{name}' is not an unmonitored deployment"), 404
        rt.cluster.set_monitor(name, True)
        rt.store.log_event(name, "Application added to monitoring", "info")
        rt.monitor.tick()
        return jsonify(ok=True)

    @app.delete("/api/apps/<name>")
    def remove_app(name):
        if name not in {a["name"] for a in rt.monitor.snapshot["apps"]}:
            return jsonify(ok=False, message="Not monitored"), 404
        rt.cluster.set_monitor(name, False)
        rt.store.log_event(name, "Application removed from monitoring", "info")
        rt.monitor.tick()
        return jsonify(ok=True)

    # ---- incidents ------------------------------------------------------
    @app.get("/api/incidents")
    def incidents():
        status = request.args.get("status")
        return jsonify(incidents=[_incident_out(i) for i in rt.store.list_incidents(status)])

    @app.get("/api/summary")
    def summary():
        return jsonify(rt.store.summary())

    @app.get("/api/incidents.csv")
    def incidents_csv():
        out = io.StringIO()
        w = csv.writer(out)
        w.writerow(["id", "detected_at", "application", "type", "severity", "status", "source", "action",
                    "recovery_seconds", "description"])
        for i in rt.store.list_incidents(limit=1000):
            w.writerow([i["id"], i["detected_at"], i["application"], i["type"], i["severity"], i["status"],
                        i["source"], i["action"] or "", i["recovery_seconds"] if i["recovery_seconds"] is not None else "",
                        (i["description"] or "").replace("\n", " ")])
        return Response(out.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=kubeguard-incidents.csv"})

    @app.get("/api/incidents/<int:iid>")
    def incident(iid):
        i = rt.store.get_incident(iid)
        if not i:
            return jsonify(error="not found"), 404
        i["live"] = rt.monitor.app_state(i["application"]) if i["status"] == "ACTIVE" else None
        return jsonify(_incident_out(i))

    # ---- metrics --------------------------------------------------------
    @app.get("/api/metrics/overview")
    def metrics_overview():
        secs = RANGES.get(request.args.get("range", "1h"), 3600)
        s = rt.metrics.overview_series(secs)
        peak = max((v for _, v in s["requests"]), default=0)
        s["requests_pct"] = [[t, 100 * v / peak] for t, v in s["requests"]] if peak else []
        s["request_peak"] = peak
        return jsonify(s)

    @app.get("/api/metrics/app/<name>")
    def metrics_app(name):
        secs = RANGES.get(request.args.get("range", "1h"), 3600)
        try:
            info = rt.cluster.get_app(name)
        except Exception:
            return jsonify(error="unknown application"), 404
        st = rt.store.get_settings()
        import time as _t
        cutoff = _t.time() - secs
        marks = [{"t": i["detected_at"], "id": i["id"], "status": i["status"], "label": INCIDENT_TYPES.get(i["type"], i["type"])}
                 for i in rt.store.list_incidents(limit=200) if i["application"] == name and i["detected_at"] >= cutoff]
        out = {m: rt.metrics.series(info, m, secs) for m in ("cpu", "memory", "response", "errors")}
        out["incidents"] = marks
        out["thresholds"] = {"cpu": st["cpu_critical"], "memory": st["memory_critical"], "errors": st["error_rate_critical"]}
        return jsonify(out)

    # ---- settings -------------------------------------------------------
    @app.get("/api/settings")
    def get_settings():
        return jsonify(rt.store.get_settings())

    @app.route("/api/settings", methods=["POST", "PUT"])
    def put_settings():
        try:
            return jsonify(rt.store.save_settings(request.get_json(silent=True) or {}))
        except (TypeError, ValueError):
            return jsonify(error="settings must be numeric"), 400

    @app.post("/api/settings/reset")
    def reset_settings():
        return jsonify(rt.store.save_settings(DEFAULT_SETTINGS))

    # ---- experiments ----------------------------------------------------
    @app.get("/api/experiments/active")
    def experiments_active():
        return jsonify(active=rt.experiments.active())

    @app.post("/api/experiments/stop")
    def experiments_stop():
        return jsonify(rt.experiments.stop((request.get_json(silent=True) or {}).get("application")))

    @app.post("/api/experiments/<kind>")
    def experiments_run(kind):
        body = request.get_json(silent=True) or {}
        try:
            return jsonify(rt.experiments.run(kind, body.get("application", "backend"),
                                              int(body.get("seconds", 90))))
        except ExperimentError as exc:
            return jsonify(ok=False, message=str(exc)), exc.status
        except (TypeError, ValueError):
            return jsonify(ok=False, message="seconds must be a number"), 400

    return app
