"""Composite health score (0-100) for an application."""


def score_app(desired, ready, m, st):
    """Return (score, status, reasons).

    Starts at 100 and subtracts penalties for lost availability, CPU/memory
    pressure, 5xx errors and slow responses. Missing metrics (None) never
    penalise an app: we only score what we can actually measure.
    """
    if desired <= 0:
        return 0, "stopped", ["Scaled to zero replicas"]

    score, reasons = 100.0, []
    avail = ready / desired
    if avail < 1:
        score -= (1 - avail) * 100
        reasons.append(f"{ready}/{desired} replicas ready")

    cpu_warn = st["cpu_critical"] - 20
    cpu = m.get("cpu_pct")
    if cpu is not None and cpu > cpu_warn:
        score -= min(25, (cpu - cpu_warn) / 20 * 25)
        reasons.append(f"CPU at {cpu:.0f}%")

    mem_warn = st["memory_critical"] - 20
    mem = m.get("mem_pct")
    if mem is not None and mem > mem_warn:
        score -= min(20, (mem - mem_warn) / 20 * 20)
        reasons.append(f"Memory at {mem:.0f}%")

    err = m.get("err_pct")
    if err is not None and err > 0.5:
        score -= min(30, err * 3)
        reasons.append(f"{err:.1f}% errors")

    resp, lat = m.get("resp_ms"), st["latency_warn_ms"]
    if resp is not None and resp > lat:
        score -= min(15, (resp - lat) / lat * 15)
        reasons.append(f"Response time {resp:.0f} ms")

    score = int(round(max(0, min(100, score))))
    status = "healthy" if score >= 85 else "warning" if score >= 60 else "critical"
    return score, status, reasons
