"""SQLite persistence for incidents, settings and the activity log."""
import json
import os
import sqlite3
import time
from contextlib import closing

DEFAULT_SETTINGS = {
    "auto_recovery": 1,            # 1 = act, 0 = observe only
    "cpu_critical": 90.0,          # % of CPU limit
    "memory_critical": 90.0,       # % of memory limit
    "error_rate_critical": 5.0,    # % of requests returning 5xx
    "latency_warn_ms": 300.0,      # only affects the health score
    "sustain_seconds": 30.0,       # breach must last this long before an incident is raised
    "cooldown_seconds": 120.0,     # minimum gap between incidents of the same type
    "max_replicas": 3.0,           # upper bound for automatic scale-out
    "verify_timeout": 120.0,       # give up verifying recovery after this long
    "self_heal_grace": 15.0,       # let Kubernetes replace a failed pod before KubeHeal acts
    "scale_down_idle_seconds": 120.0,
}

SETTING_LIMITS = {
    "cpu_critical": (10, 100), "memory_critical": (10, 100), "error_rate_critical": (0.5, 100),
    "latency_warn_ms": (10, 10000), "sustain_seconds": (0, 3600), "cooldown_seconds": (0, 86400),
    "max_replicas": (1, 10), "verify_timeout": (10, 1800), "self_heal_grace": (0, 300),
    "scale_down_idle_seconds": (10, 86400),
}

_SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  application TEXT NOT NULL, type TEXT NOT NULL, severity TEXT NOT NULL,
  status TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'auto',
  description TEXT, action TEXT,
  detected_at REAL NOT NULL, resolved_at REAL, recovery_seconds REAL,
  before_json TEXT, after_json TEXT, steps_json TEXT);
CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL,
  application TEXT, level TEXT NOT NULL, message TEXT NOT NULL);
"""

MAX_INCIDENTS = 1000
_JSON_COLS = {"before_json": "before", "after_json": "after", "steps_json": "steps"}


class Store:
    def __init__(self, path):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with closing(self._conn()) as c, c:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript(_SCHEMA)
            for k, v in DEFAULT_SETTINGS.items():
                c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)", (k, str(v)))

    def _conn(self):
        c = sqlite3.connect(self.path, timeout=15)
        c.row_factory = sqlite3.Row
        return c

    # ---- settings -------------------------------------------------------
    def get_settings(self):
        with closing(self._conn()) as c:
            raw = {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM settings")}
        out = dict(DEFAULT_SETTINGS)
        for k in DEFAULT_SETTINGS:
            if k in raw:
                try:
                    out[k] = float(raw[k])
                except ValueError:
                    pass
        return out

    def save_settings(self, data):
        with closing(self._conn()) as c, c:
            for k, v in (data or {}).items():
                if k not in DEFAULT_SETTINGS:
                    continue
                v = float(v)
                if k == "auto_recovery":
                    v = 1.0 if v else 0.0
                else:
                    lo, hi = SETTING_LIMITS[k]
                    v = min(max(v, lo), hi)
                c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, str(v)))
        return self.get_settings()

    # ---- incidents ------------------------------------------------------
    @staticmethod
    def _row(r):
        d = dict(r)
        for col, name in _JSON_COLS.items():
            raw = d.pop(col, None)
            d[name] = json.loads(raw) if raw else ([] if name == "steps" else None)
        return d

    def create_incident(self, application, typ, severity, description, before, source="auto",
                        action=None, steps=None):
        with closing(self._conn()) as c, c:
            cur = c.execute(
                "INSERT INTO incidents(application,type,severity,status,source,description,action,"
                "detected_at,before_json,steps_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (application, typ, severity, "ACTIVE", source, description, action, time.time(),
                 json.dumps(before), json.dumps(steps or [])))
            iid = cur.lastrowid
            c.execute("DELETE FROM incidents WHERE id <= ?", (iid - MAX_INCIDENTS,))   # retention
            return iid

    def update_incident(self, iid, **kw):
        if not kw:
            return
        cols, vals = [], []
        for k, v in kw.items():
            if k in ("before", "after", "steps"):
                k, v = k + "_json", json.dumps(v)
            cols.append(f"{k}=?")
            vals.append(v)
        with closing(self._conn()) as c, c:
            c.execute(f"UPDATE incidents SET {','.join(cols)} WHERE id=?", vals + [iid])

    def get_incident(self, iid):
        with closing(self._conn()) as c:
            r = c.execute("SELECT * FROM incidents WHERE id=?", (iid,)).fetchone()
        return self._row(r) if r else None

    def list_incidents(self, status=None, limit=200):
        q, args = "SELECT * FROM incidents", []
        if status:
            q += " WHERE status=?"
            args.append(status.upper())
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with closing(self._conn()) as c:
            return [self._row(r) for r in c.execute(q, args)]

    def counts(self):
        with closing(self._conn()) as c:
            active = c.execute("SELECT COUNT(*) FROM incidents WHERE status='ACTIVE'").fetchone()[0]
            rec = c.execute("SELECT COUNT(*) FROM incidents WHERE status='RECOVERED' AND resolved_at>?",
                            (time.time() - 86400,)).fetchone()[0]
        return {"active": active, "recoveries_24h": rec}

    def summary(self):
        """Headline numbers for the Incidents page."""
        with closing(self._conn()) as c:
            rows = c.execute("SELECT status, COUNT(*) n, AVG(recovery_seconds) avg_s FROM incidents GROUP BY status").fetchall()
            by_type = {r["type"]: r["n"] for r in c.execute("SELECT type, COUNT(*) n FROM incidents GROUP BY type")}
        n = {r["status"]: r["n"] for r in rows}
        avg = {r["status"]: r["avg_s"] for r in rows}
        rec, failed, active = n.get("RECOVERED", 0), n.get("FAILED", 0), n.get("ACTIVE", 0)
        finished = rec + failed
        return {"total": rec + failed + active, "recovered": rec, "failed": failed, "active": active,
                "success_rate": round(100 * rec / finished, 1) if finished else None,
                "mttr_seconds": round(avg["RECOVERED"], 1) if avg.get("RECOVERED") is not None else None,
                "by_type": by_type}

    def close_stale(self):
        """Incidents left ACTIVE by a previous process can never complete; close them."""
        with closing(self._conn()) as c, c:
            c.execute("UPDATE incidents SET status='FAILED', resolved_at=?, "
                      "description=COALESCE(description,'')||' [KubeHeal restarted during recovery]' "
                      "WHERE status='ACTIVE'", (time.time(),))

    # ---- activity log ---------------------------------------------------
    def log_event(self, application, message, level="info"):
        with closing(self._conn()) as c, c:
            c.execute("INSERT INTO events(ts,application,level,message) VALUES(?,?,?,?)",
                      (time.time(), application, level, message))
            c.execute("DELETE FROM events WHERE id <= (SELECT MAX(id) FROM events) - 500")

    def list_events(self, limit=15):
        with closing(self._conn()) as c:
            return [dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))]
