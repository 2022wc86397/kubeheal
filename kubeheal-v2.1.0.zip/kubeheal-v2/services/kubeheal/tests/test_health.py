import pytest
from app.db import DEFAULT_SETTINGS
from app.health import score_app

ST = dict(DEFAULT_SETTINGS)
OK = {"cpu_pct": 30, "mem_pct": 40, "err_pct": 0.1, "resp_ms": 90}


def test_healthy():
    s, status, _ = score_app(2, 2, OK, ST)
    assert s >= 95 and status == "healthy"


def test_missing_metrics_do_not_penalise():
    assert score_app(2, 2, {}, ST)[0] == 100


def test_degraded_app_is_warning():
    m = {"cpu_pct": 78, "mem_pct": 69, "err_pct": 2.3, "resp_ms": 450}
    s, status, reasons = score_app(3, 3, m, ST)
    assert 60 <= s < 85 and status == "warning" and reasons


def test_lost_replicas_hurt():
    s, status, _ = score_app(2, 1, OK, ST)
    assert s <= 55 and status == "critical"


def test_scaled_to_zero():
    assert score_app(0, 0, OK, ST)[:2] == (0, "stopped")


@pytest.mark.parametrize("cpu,mem,err", [(100, 100, 100), (0, 0, 0)])
def test_score_is_bounded(cpu, mem, err):
    s, _, _ = score_app(1, 0, {"cpu_pct": cpu, "mem_pct": mem, "err_pct": err, "resp_ms": 9999}, ST)
    assert 0 <= s <= 100
