"""End-to-end flows against the simulator: real detection -> recovery -> verification."""
from app.recovery import STEPS


def done_incident(rt, typ, timeout=40):
    assert rt.wait(lambda: (rt.incident_for(typ) or {}).get("status") in ("RECOVERED", "FAILED"), timeout), \
        f"no finished {typ} incident: {rt.store.list_incidents()}"
    return rt.incident_for(typ)


def run_experiment(rt, kind, app="backend", seconds=20):
    rt.monitor.tick()
    return rt.experiments.run(kind, app, seconds)


def test_cpu_overload_scales_out_then_back_in(rt):
    run_experiment(rt, "cpu", seconds=60)
    inc = done_incident(rt, "CPU_OVERLOAD")
    assert inc["status"] == "RECOVERED", inc
    assert inc["action"] == "Scale Replicas"
    assert rt.world.get_app("backend").desired == 3
    assert inc["before"]["cpu_pct"] >= 90 and inc["after"]["cpu_pct"] < 90
    assert [s["state"] for s in inc["steps"]] == ["done"] * len(STEPS)
    assert "from 2 to 3" in inc["steps"][2]["detail"]

    # stop the fault: load drops, KubeHeal returns to the baseline replica count
    rt.experiments.stop("backend")
    assert rt.wait(lambda: rt.world.get_app("backend").desired == 2, 40)


def test_memory_pressure_rolling_restart(rt):
    run_experiment(rt, "memory", seconds=60)
    inc = done_incident(rt, "MEMORY_PRESSURE")
    assert inc["status"] == "RECOVERED" and inc["action"] == "Restart Deployment"
    assert inc["before"]["mem_pct"] >= 90 and inc["after"]["mem_pct"] < 90
    assert rt.world.get_app("backend").rollout_complete


def test_error_rate_rolling_restart(rt):
    run_experiment(rt, "errors", seconds=60)
    inc = done_incident(rt, "HIGH_ERROR_RATE")
    assert inc["status"] == "RECOVERED" and inc["action"] == "Restart Deployment"
    assert inc["before"]["err_pct"] >= 5 and inc["after"]["err_pct"] < 5


def test_crash_pod_is_self_healed_and_verified(rt):
    res = run_experiment(rt, "crash", app="frontend")
    assert res["incident"]
    inc = done_incident(rt, "POD_FAILURE")
    assert inc["status"] == "RECOVERED" and inc["source"] == "experiment"
    assert inc["action"] == "Kubernetes self-heal"
    assert 0 < inc["recovery_seconds"] < 20
    assert inc["before"]["cpu_pct"] is not None and inc["before"]["mem_pct"] is not None   # real metrics, not blanks


def test_stuck_pod_escalates_to_deployment_restart(rt):
    rt.world.startup = 600          # replacement pods never become ready within the grace period
    run_experiment(rt, "crash", app="backend")
    rt.world.list_pods("backend")   # controller spawns the (stuck) replacement now
    rt.world.startup = 0.4          # ...so only the escalated restart can create healthy pods
    inc = done_incident(rt, "POD_FAILURE")
    assert inc["status"] == "RECOVERED"
    assert inc["action"] in ("Restart Pods", "Restart Deployment")


def test_auto_recovery_disabled_is_observe_only(rt):
    rt.store.save_settings({"auto_recovery": 0, "verify_timeout": 10})
    run_experiment(rt, "cpu", seconds=60)
    inc = done_incident(rt, "CPU_OVERLOAD", timeout=30)
    assert inc["action"] == "Observe only"
    assert rt.world.get_app("backend").desired == 2          # nothing was changed
    assert inc["status"] == "FAILED"                          # condition never cleared on its own
    for _ in range(8):                                        # ...and KubeHeal does not spam new incidents
        rt.monitor.tick()
    assert len(rt.store.list_incidents()) == 1


def test_scale_out_respects_max_replicas(rt):
    rt.store.save_settings({"max_replicas": 2, "verify_timeout": 10})
    run_experiment(rt, "cpu", seconds=60)
    inc = done_incident(rt, "CPU_OVERLOAD", timeout=30)
    assert rt.world.get_app("backend").desired == 2
    assert inc["action"] == "Observe only" and inc["status"] == "FAILED"


def test_one_incident_per_app_and_cooldown(rt):
    rt.store.save_settings({"cooldown_seconds": 3600})
    run_experiment(rt, "cpu", seconds=60)
    done_incident(rt, "CPU_OVERLOAD")
    for _ in range(10):
        rt.monitor.tick()
    assert len([i for i in rt.store.list_incidents() if i["type"] == "CPU_OVERLOAD"]) == 1


def test_busy_app_rejects_second_experiment(rt):
    from app.experiments import ExperimentError
    import pytest
    run_experiment(rt, "crash", app="backend")
    with pytest.raises(ExperimentError) as e:
        rt.experiments.run("crash", "backend")
    assert e.value.status == 409
    done_incident(rt, "POD_FAILURE")


def test_unknown_app_and_kind(rt):
    from app.experiments import ExperimentError
    import pytest
    with pytest.raises(ExperimentError):
        rt.experiments.run("cpu", "nope")
    with pytest.raises(ExperimentError):
        rt.experiments.run("bogus", "backend")
