# KubeHeal / KubeGuard v2

Kubernetes application health monitoring with **real fault detection and automatic recovery**, built only from
open-source parts and sized for a 2 vCPU AWS instance.

| Component | Tool | Why |
|---|---|---|
| Kubernetes | **k3s** | ~500 MB RAM vs ~1.5 GB for Minikube-in-Docker |
| Metrics | **Prometheus** (single pod) | CPU/memory via the kubelet's built-in cAdvisor, app metrics via pod scraping. No operator, Grafana, Alertmanager, node-exporter or kube-state-metrics |
| Control plane | **KubeHeal** (Flask + SQLite) | detector, recovery engine, REST API and dashboard in one 80 MB pod |
| Demo workload | `demo-app` (Flask) | exposes `/metrics` and **real** CPU / memory / error fault injection |

## Architecture

```
 Browser ──► KubeHeal (kubeheal-system)  ───────────── Kubernetes API (namespace-scoped RBAC)
              │  monitor loop every 10 s                 · list/patch deployments, delete pods
              │  detect → recover → verify               · scale / rolling restart
              │  SQLite on a PVC (incidents, settings)
              ▼
         Prometheus (monitoring) ◄── kubelet cAdvisor (container CPU / memory)
              ▲                  ◄── demo pods :8080/metrics (requests, 5xx, latency)
              │
   frontend / backend / database  (kubeheal-demo, quota: 10 pods)   loadgen = steady traffic
```

## Quick start (fresh Ubuntu 22.04/24.04 host)

```bash
unzip kubeheal-v2.zip && cd kubeheal-v2
./install.sh            # ~5-8 minutes: swap, Docker, k3s, build, deploy
```
At the end it prints the URL and a generated password. Open `http://<EC2-PUBLIC-IP>:30080` (user `admin`).
Allow **TCP 30080 from your IP only**, or use an SSH tunnel: `ssh -L 8080:localhost:30080 ubuntu@<host>`.

**Instance sizing:** 2 vCPU with 2 GB RAM is the minimum (the installer adds 2 GB swap); 4 GB is comfortable.
A 1 vCPU / 1 GB instance (t2/t3.micro) is too small. Check which 2-vCPU types your AWS account's free plan includes.

Steady state uses roughly: k3s 500 MB, Prometheus 250 MB, KubeHeal 80 MB, 6 demo pods x ~45 MB.

**No Kubernetes handy?** `make mock` (or `./scripts/run-mock.sh`) runs the same dashboard against a built-in simulator on
http://localhost:8080. The experiments work there too.

## Try it

Open **Experiments**, pick `backend`, and trigger a fault. Each one is a real fault, not an inserted row:

| Experiment | What happens in the pods | Detected as | Recovery action |
|---|---|---|---|
| Crash Pod | a ready pod is deleted | Pod Failure (opened immediately) | wait `self_heal_grace`, then delete unhealthy pods, then rolling restart |
| CPU Stress | busy loop in every pod, throttled at the 200m limit | CPU Overload (>= 90% for 30 s) | **scale replicas +1** (max 3); scale back to baseline after load stays low |
| Memory Stress | each pod allocates up to 93% of its 192 Mi limit | Memory Pressure (>= 90% for 30 s) | rolling restart |
| Generate Errors | pods answer 60% of requests with HTTP 500 | High Error Rate (>= 5% for 30 s) | rolling restart |

Watch **Incidents** > View: timeline (Detected, Classifying, Executing, Verifying, Completed), metrics before and live
after recovery. An incident is closed as *Recovered* only when the rollout is complete **and** the triggering metric
has stayed below its threshold for two consecutive checks. Otherwise it is *Failed*.

## Safety rules built into the engine

* One recovery per application at a time; a breach is **latched**: no new incident (and no restart loop) until the
  condition has cleared once. Cooldown (default 120 s) guards against flapping.
* Scale-out is bounded by `max_replicas` and by the namespace ResourceQuota (10 pods, 2 CPU limits).
* **Auto-recovery switch** in Settings: off = detect and record only.
* Least-privilege RBAC: KubeHeal can only touch one namespace; Prometheus reads only nodes and the demo pods.
* Optional HTTP basic auth (the installer generates a password). `/api/health` stays open for probes.
* Incidents left running when KubeHeal restarts are closed as *Failed* instead of hanging forever.

## Adding your own application

Dashboard > Applications > **Add Application** lists unmonitored Deployments in the namespace and labels them
`kubeheal.io/monitor=true`. Percentages need CPU/memory **limits** on the container. Request/error/latency metrics
need `prometheus.io/scrape: "true"` + `prometheus.io/port` on the pod template and `http_requests_total{code}` and
`http_request_duration_seconds` metrics. Without them those values show as "–" and are excluded from the health score.
To watch another namespace, change `WATCH_NAMESPACE`, the Roles, and the Prometheus `namespaces.names`.

## Settings (Settings page, stored in SQLite)

`sustain_seconds` 30, `cpu_critical` 90, `memory_critical` 90, `error_rate_critical` 5, `latency_warn_ms` 300,
`max_replicas` 3, `cooldown_seconds` 120, `verify_timeout` 120, `self_heal_grace` 15, `scale_down_idle_seconds` 120.
Environment (see `app/config.py`): `WATCH_NAMESPACE`, `PROMETHEUS_URL`, `DB_PATH`, `DETECT_INTERVAL_SECONDS`, `BRAND_NAME`,
`AUTH_USER`/`AUTH_PASSWORD`, `KUBEHEAL_MODE=cluster|mock`.

Health score = 100 minus penalties for lost replicas, CPU/memory above (threshold - 20), 5xx rate and latency.
Healthy >= 85, Warning >= 60, otherwise Critical (`app/health.py`).

## Layout

```
install.sh / uninstall.sh      one-shot lifecycle          scripts/verify.sh   pipeline diagnostics
deploy/k8s/                    namespaces+quota, prometheus, demo apps, kubeheal (RBAC, PVC, Service)
services/kubeheal/             app/ (monitor, recovery, experiments, prom, k8s, mock, db, main) static/ tests/
services/demo-app/             app.py (metrics + chaos), loadgen.py
.github/workflows/ci.yaml      tests, manifest + shell checks, image builds
```

## Troubleshooting

Start with `scripts/verify.sh`: it checks pods, Prometheus targets (with scrape errors), key queries and the API.

| Symptom | Root cause / fix |
|---|---|
| Dashboard banner "Prometheus is not answering" | `kubectl -n monitoring logs deploy/prometheus`; check the pod is Running and `verify.sh` shows targets up |
| `cadvisor` target down, 401/403 | the ClusterRole `prometheus-kubelet-read` must include `nodes/metrics` (it does by default) |
| CPU/memory show "–" | the container has no CPU/memory limit, so a percentage is undefined; set limits |
| Error rate / latency show "–" | traffic below 0.05 req/s or pod lacks the scrape annotation; check `loadgen` is running |
| Pod `ImagePullBackOff` for kubeheal images | images weren't imported into the runtime: `sudo docker save IMG | sudo k3s ctr images import -` |
| Experiment says "No pod accepted" | the app isn't built from the demo-app image (only it has `/chaos/*`) |
| CPU experiment never triggers | demo pods have 200m limits; check Settings thresholds and that `sustain_seconds` has elapsed |
| Pods Pending after scale-out | namespace quota (10 pods) or node memory exhausted; `kubectl describe resourcequota -n kubeheal-demo` |
| Lost incident history | the PVC `kubeheal-data` was deleted (`uninstall.sh`) |

## Security notes

The dashboard can delete pods and change replicas. Keep it behind the SG allow-list or SSH tunnel and keep basic auth on
(it sends the password in clear text over plain HTTP; put it behind TLS for anything beyond a lab). The demo app's
`/chaos/*` endpoints are unauthenticated and reachable inside the cluster; do not reuse the demo image for real workloads.

## What changed from the previous scripts

* Phase scripts that wrote code via heredocs became a proper project with tests and CI.
* "CPU / memory / restart detection tests" used to insert fake incident rows. Experiments now inject real faults and
  recovery is detected from metrics and verified from metrics.
* Demo apps were plain nginx (no way to create CPU, memory or error load, no request metrics); now they are instrumented.
* kube-prometheus-stack (~1.5 GB) replaced by a single lean Prometheus; Minikube replaced by k3s.
* Recovery actions are real and bounded: scale-out, pod restart, rolling restart, scale-down, with escalation and verification.
* Added: health score, ResourceQuota, least-privilege RBAC, auth, `Recreate` strategy for the SQLite volume, restart-loop latch,
  non-root containers, swap setup, and the full dashboard (Applications, Pods, Incident detail, Metrics, Settings, Add Application).

## Testing

`make test`: 38 tests (health scoring, SQLite store, API incl. auth, the Kubernetes and Prometheus backends against fakes, and
end-to-end detect > recover > verify flows against the simulator). The simulator and the dashboard JS were also exercised
end to end. The k3s/AWS install path itself needs a real host: run `./install.sh`, then `scripts/verify.sh`.
