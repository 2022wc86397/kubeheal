/* KubeGuard dashboard: dependency-free single page app. */
'use strict';

const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num = (v, d = 0) => v == null ? '–' : Number(v).toFixed(d);
const pct = (v, d = 0) => v == null ? '–' : num(v, d) + '%';
const hms = ts => ts ? new Date(ts * 1000).toLocaleTimeString([], {hour12: false}) : '';
const dur = s => s == null ? '–' : s.toFixed(1) + 's';
const sev = v => String(v || '').toLowerCase();

const IC = {
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  box: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
  layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  alert: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  bars: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m5 0V4a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v2"/>',
  cpu: '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
  db: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
  tri: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  recycle: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
};
const ico = (n, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;

const NAV = [['dashboard', 'Dashboard', 'grid'], ['applications', 'Applications', 'box'], ['pods', 'Pods', 'layers'],
  ['incidents', 'Incidents', 'alert'], ['experiments', 'Experiments', 'zap'], ['metrics', 'Metrics', 'bars'],
  ['settings', 'Settings', 'sliders']];

const S = {cfg: {}, ov: null, spark: {}, sparkAt: 0, overview: null, overviewAt: 0, filter: 'all', range: '1h',
           route: {}, podApp: '', settings: null};

/* ------------------------------------------------------------------ api */
async function api(path, opts) {
  const r = await fetch(path, {cache: 'no-store', ...opts});
  let body = {};
  try { body = await r.json(); } catch (_) { /* non-JSON error page */ }
  if (!r.ok && !body.message && !body.error) body = {ok: false, message: `Request failed (${r.status})`};
  return {ok: r.ok, status: r.status, data: body};
}
const post = (path, body) => api(path, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})});

let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 4500);
}

/* --------------------------------------------------------------- charts */
function niceMax(v) { if (v <= 0) return 1; const p = 10 ** Math.floor(Math.log10(v)); return [1, 2, 5, 10].map(m => m * p).find(m => m >= v * 1.05); }

function lineChart(series, {max = null, unit = '', h = 190, fill = false} = {}) {
  const pts = series.flatMap(s => s.points);
  if (!pts.length) return '<div class="empty small">No data yet. Metrics appear after the first scrapes.</div>';
  const W = 640, L = 40, R = 10, T = 10, B = 24, w = W - L - R, ht = h - T - B;
  const t0 = Math.min(...pts.map(p => p[0])), t1 = Math.max(...pts.map(p => p[0])) || t0 + 1;
  const ymax = max ?? niceMax(Math.max(...pts.map(p => p[1])));
  const X = t => L + (t1 === t0 ? 0 : (t - t0) / (t1 - t0) * w), Y = v => T + ht - Math.min(v, ymax) / ymax * ht;
  let g = '';
  for (let i = 0; i <= 4; i++) {
    const v = ymax * i / 4, y = Y(v);
    g += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="#e8edf5"/><text class="axis" x="${L - 6}" y="${y + 3}" text-anchor="end">${+v.toFixed(1)}${unit}</text>`;
  }
  for (let i = 0; i <= 4; i++) {
    const t = t0 + (t1 - t0) * i / 4;
    g += `<text class="axis" x="${X(t)}" y="${h - 6}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${new Date(t * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', hour12: false})}</text>`;
  }
  const paths = series.map(s => {
    if (!s.points.length) return '';
    const d = s.points.map((p, i) => `${i ? 'L' : 'M'}${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join('');
    const area = fill ? `<path d="${d}L${X(s.points.at(-1)[0])},${T + ht}L${X(s.points[0][0])},${T + ht}Z" fill="${s.color}" opacity=".08"/>` : '';
    return `${area}<path d="${d}" fill="none" stroke="${s.color}" stroke-width="1.8" stroke-linejoin="round"/>`;
  }).join('');
  return `<svg viewBox="0 0 ${W} ${h}" role="img" aria-label="${esc(series.map(s => s.name).join(', '))} over time">${g}${paths}</svg>`;
}

const legend = items => `<div class="legend">${items.map(([n, c]) => `<span><i style="background:${c}"></i>${n}</span>`).join('')}</div>`;

function donut(value, label, color) {
  const r = 42, c = 2 * Math.PI * r, v = Math.max(0, Math.min(100, value ?? 0));
  return `<div class="donut"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="${r}" fill="none" stroke="#e8edf5" stroke-width="9"/>
    <circle cx="50" cy="50" r="${r}" fill="none" stroke="${color}" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c * v / 100} ${c}"/></svg>
    <div class="c"><small>${label}</small><b>${value == null ? '–' : Math.round(value) + '%'}</b></div></div>`;
}

function spark(points, color) {
  if (!points || points.length < 2) return '';
  const t0 = points[0][0], t1 = points.at(-1)[0] || t0 + 1, vs = points.map(p => p[1]), lo = Math.min(...vs), hi = Math.max(...vs, lo + 1);
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${((p[0] - t0) / (t1 - t0) * 200).toFixed(1)},${(38 - (p[1] - lo) / (hi - lo) * 34).toFixed(1)}`).join('');
  return `<svg viewBox="0 0 200 42" preserveAspectRatio="none"><path d="${d}L200,42L0,42Z" fill="${color}" opacity=".1"/><path d="${d}" fill="none" stroke="${color}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
}

const statusColor = s => s === 'healthy' ? 'var(--green)' : s === 'warning' ? 'var(--amber)' : 'var(--red)';
const bar = (v, cls = '') => `<div class="bar"><i class="${cls}" style="width:${Math.max(0, Math.min(100, v ?? 0))}%"></i></div>`;
const head = (title, sub, right = '') => `<div class="page-head"><div><h1>${title}</h1>${sub ? `<p class="sub">${sub}</p>` : ''}</div><div class="head-right">${right}</div></div>`;

/* ---------------------------------------------------------------- views */
const V = {};

V.dashboard = {
  render() {
    $('#main').innerHTML = `<div id="dash"></div>`;
    this.refresh();
  },
  async refresh() {
    const o = S.ov; if (!o || !$('#dash')) return;
    const c = o.counts, cl = o.cluster || {};
    const right = `<span><span class="dot ${o.cluster_connected ? '' : 'off'}"></span> ${o.cluster_connected ? 'Cluster Connected' : 'Cluster Unreachable'}</span>
      <span>${new Date().toLocaleString([], {dateStyle: 'medium', timeStyle: 'medium', hour12: false})}</span>
      <button class="icon-btn" id="rf" title="Refresh" aria-label="Refresh">${ico('refresh')}</button>`;
    const warn = !o.cluster_connected ? `<div class="banner">Cannot reach the Kubernetes API: ${esc(o.error || 'unknown error')}</div>`
      : !o.prometheus_ok ? `<div class="banner">Prometheus is not answering, so CPU, memory and latency are unavailable. Availability checks still work.</div>` : '';
    const tile = (cls, icon, n, label, sub) => `<div class="tile ${cls}"><div class="ti">${ico(icon)}</div><div><div class="n">${n}</div><div class="l">${label}</div><div class="s">${sub}</div></div></div>`;
    const podsMax = cl.pods_max;
    $('#dash').innerHTML = head('Dashboard', 'Kubernetes Application Health &amp; Auto-Recovery', right) + warn + `
      <div class="grid g4">
        ${tile('green', 'box', c.applications, 'Applications', `${c.healthy} Healthy ${c.warning + c.critical} Warning`)}
        ${tile('blue', 'layers', c.pods, 'Pods', `${c.running} Running ${c.not_ready} Restarting`)}
        ${tile('red', 'alert', c.active, 'Active Incident', c.active ? 'Auto-recovery in progress' : 'All clear')}
        ${tile('purple', 'recycle', c.recoveries_24h, 'Successful Recoveries', 'Last 24 hours')}
      </div>
      <div class="split mt">
        <div class="card"><h2>Application Health</h2>${o.apps.map(a => `
          <div class="health-row"><b>${esc(a.name)}</b>${bar(a.score, a.status)}<span class="num">${a.score}%</span><span class="pill ${a.status}">${a.status[0].toUpperCase() + a.status.slice(1)}</span></div>`).join('') || '<div class="empty">No monitored applications</div>'}</div>
        <div class="card"><h2>Cluster Resource Usage</h2><div class="donuts">
          ${donut(cl.cpu_pct, 'CPU', 'var(--blue)')}${donut(cl.mem_pct, 'Memory', 'var(--green)')}
          ${podsMax ? donut(100 * cl.pods_used / podsMax, 'Pods', 'var(--purple)').replace(/<b>.*?<\/b>/, `<b>${cl.pods_used}/${podsMax}</b>`) : donut(null, 'Pods', 'var(--purple)').replace(/<b>.*?<\/b>/, `<b>${cl.pods_used ?? '–'}</b>`)}
        </div></div>
      </div>
      <div class="card mt"><h2>Metrics Overview (Last 1 Hour)</h2><div id="ovchart" class="chart"></div></div>
      <div class="card mt"><h2>Recent activity</h2><ul class="feed">${(o.events || []).map(e => `<li><time>${hms(e.ts)}</time><span class="${e.level === 'error' ? 'bad' : e.level === 'ok' ? 'ok' : ''}">${esc(e.message)}</span></li>`).join('') || '<li class="muted">Nothing yet. Trigger an experiment to see KubeGuard work.</li>'}</ul></div>`;
    $('#rf').onclick = () => tick();
    this.chart();
  },
  async chart() {
    if (!$('#ovchart')) return;
    if (Date.now() - S.overviewAt > 15000) {
      const r = await api('/api/metrics/overview?range=1h'); if (r.ok) { S.overview = r.data; S.overviewAt = Date.now(); }
    }
    const m = S.overview; if (!m || !$('#ovchart')) return;
    const L = [['CPU (%)', 'var(--blue)'], ['Memory (%)', 'var(--green)'], ['Request Rate (% of peak)', 'var(--purple)'], ['Error Rate (%)', 'var(--red)']];
    $('#ovchart').innerHTML = legend(L) + lineChart([
      {name: 'CPU', color: '#1769e0', points: m.cpu}, {name: 'Memory', color: '#12a05c', points: m.memory},
      {name: 'Requests', color: '#7a3de0', points: m.requests_pct || []}, {name: 'Errors', color: '#dc3a3a', points: m.errors}], {max: 100, unit: ''});
  }
};

V.applications = {
  render() { $('#main').innerHTML = `<div id="apps"></div>`; this.refresh(); this.sparks(); },
  async sparks() {
    if (Date.now() - S.sparkAt < 15000 || !S.ov) return;
    S.sparkAt = Date.now();
    await Promise.all(S.ov.apps.map(async a => { const r = await api(`/api/metrics/app/${encodeURIComponent(a.name)}?range=15m`); if (r.ok) S.spark[a.name] = r.data.cpu; }));
    this.refresh();
  },
  refresh() {
    const o = S.ov; if (!o || !$('#apps')) return;
    $('#apps').innerHTML = head('Applications', 'Manage and monitor your Kubernetes applications', `<button class="btn" id="addapp">+ Add Application</button>`) +
      `<div class="grid g3">${o.apps.map(a => `
      <div class="card app ${a.status}">
        <div class="app-top"><span class="badge-ico">${ico('box')}</span><h3>${esc(a.name)}</h3><span class="pill ${a.status}">${a.status[0].toUpperCase() + a.status.slice(1)}</span></div>
        <div class="kpis"><div><b>${a.ready}/${a.desired}</b><span>Running Pods</span></div><div><b>${a.score}%</b><span>Health Score</span></div><div><b>${a.resp_ms == null ? '–' : num(a.resp_ms) + 'ms'}</b><span>Avg Response Time</span></div></div>
        <div class="spark" title="CPU, last 15 minutes">${spark(S.spark[a.name], statusColor(a.status).replace('var(--green)', '#12a05c').replace('var(--amber)', '#e8890c').replace('var(--red)', '#dc3a3a'))}</div>
        <div class="mini"><div><span>CPU</span><b class="${a.cpu_pct >= 90 ? 'bad' : a.cpu_pct >= 70 ? 'warn' : 'ok'}">${pct(a.cpu_pct)}</b></div><div><span>Memory</span><b class="${a.mem_pct >= 90 ? 'bad' : a.mem_pct >= 75 ? 'warn' : 'ok'}">${pct(a.mem_pct)}</b></div><div><span>Errors</span><b class="${a.err_pct >= 5 ? 'bad' : a.err_pct >= 1 ? 'warn' : 'ok'}">${pct(a.err_pct, 1)}</b></div></div>
        <div class="app-actions"><a class="btn ghost sm" style="text-align:center" href="#/metrics/${encodeURIComponent(a.name)}">View Details</a><a class="btn ghost sm" style="text-align:center" href="#/pods?app=${encodeURIComponent(a.name)}">View Pods</a></div>
      </div>`).join('') || '<div class="card empty">No monitored applications yet. Add one to start.</div>'}</div>`;
    $('#addapp').onclick = addAppDialog;
    this.sparks();
  }
};

async function addAppDialog() {
  const r = await api('/api/candidates'), list = r.data.candidates || [], m = $('#modal');
  m.innerHTML = `<h2 style="margin-bottom:6px">Add application</h2><p class="muted" style="margin-bottom:14px">Choose a Deployment in the watched namespace. KubeGuard labels it and starts monitoring.</p>
    ${list.map(n => `<div class="set-row"><b>${esc(n)}</b><button class="btn sm" data-n="${esc(n)}">Add</button></div>`).join('') || '<p class="empty">Every deployment in this namespace is already monitored.</p>'}
    <div style="text-align:right;margin-top:14px"><button class="btn ghost" id="mc">Close</button></div>`;
  m.showModal(); $('#mc').onclick = () => m.close();
  m.querySelectorAll('[data-n]').forEach(b => b.onclick = async () => {
    b.disabled = true; const res = await post('/api/apps', {name: b.dataset.n});
    toast(res.ok ? `${b.dataset.n} is now monitored` : res.data.message); m.close(); tick();
  });
}

V.pods = {
  render() {
    S.podApp = S.route.query.app || '';
    $('#main').innerHTML = head('Pods', 'Live state of every pod in the watched namespace',
      `<select id="podsel" aria-label="Filter by application"><option value="">All applications</option></select>`) +
      `<div class="card scroll"><table class="tbl"><thead><tr><th>Pod</th><th>Application</th><th>Status</th><th>Ready</th><th>Restarts</th><th>CPU</th><th>Memory</th><th>Age</th><th></th></tr></thead><tbody id="podrows"></tbody></table></div>`;
    $('#podsel').onchange = e => { S.podApp = e.target.value; this.refresh(); };
    this.refresh();
  },
  refresh() {
    const o = S.ov; if (!o || !$('#podrows')) return;
    const sel = $('#podsel'); if (sel.options.length === 1) o.apps.forEach(a => sel.add(new Option(a.name, a.name)));
    sel.value = S.podApp;
    api('/api/pods' + (S.podApp ? '?app=' + encodeURIComponent(S.podApp) : '')).then(r => {
      if (!$('#podrows')) return;
      const age = s => s < 90 ? Math.round(s) + 's' : s < 5400 ? Math.round(s / 60) + 'm' : (s / 3600).toFixed(1) + 'h';
      $('#podrows').innerHTML = (r.data.pods || []).map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.app)}</td>
        <td><span class="pill ${p.ready ? '' : 'warning'}">${esc(p.status)}</span></td><td class="${p.ready ? 'ok' : 'bad'}">${p.ready ? 'Ready' : 'Not ready'}</td>
        <td class="num">${p.restarts}</td><td class="num">${p.cpu_cores == null ? '–' : num(p.cpu_cores * 1000) + 'm'}${p.cpu_pct == null ? '' : ` <span class="muted small">(${num(p.cpu_pct)}%)</span>`}</td>
        <td class="num">${p.mem_mib == null ? '–' : num(p.mem_mib) + ' MiB'}${p.mem_pct == null ? '' : ` <span class="muted small">(${num(p.mem_pct)}%)</span>`}</td>
        <td class="num">${age(p.age_s)}</td><td><button class="btn ghost sm" data-p="${esc(p.name)}">Restart</button></td></tr>`).join('') || '<tr><td colspan="9" class="empty">No pods</td></tr>';
      document.querySelectorAll('[data-p]').forEach(b => b.onclick = async () => {
        if (!confirm(`Delete pod ${b.dataset.p}? Its Deployment will create a replacement.`)) return;
        const res = await post(`/api/pods/${encodeURIComponent(b.dataset.p)}/delete`); toast(res.ok ? 'Pod deleted; a replacement is starting' : res.data.message);
        tick();
      });
    });
  }
};

V.incidents = {
  render() {
    const id = S.route.param;
    if (id) return this.detail(id);
    $('#main').innerHTML = head('Incidents', 'View and track all detected incidents and recovery actions') +
      `<div class="card"><div class="tabs" id="tabs">${['all', 'active', 'recovered', 'failed'].map(t => `<button class="tab ${S.filter === t ? 'on' : ''}" data-t="${t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>
      <div class="scroll"><table class="tbl"><thead><tr><th>ID</th><th>Time</th><th>Application</th><th>Incident Type</th><th>Severity</th><th>Status</th><th>Recovery Action</th><th>Recovery Time</th><th>Actions</th></tr></thead><tbody id="increws"></tbody></table></div></div>`;
    document.querySelectorAll('.tab').forEach(b => b.onclick = () => { S.filter = b.dataset.t; document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === b)); this.refresh(); });
    this.refresh();
  },
  async refresh() {
    if (S.route.param) return this.detail(S.route.param);
    const r = await api('/api/incidents' + (S.filter === 'all' ? '' : '?status=' + S.filter)); if (!$('#increws')) return;
    const rows = r.data.incidents || [];
    $('#increws').innerHTML = rows.map(i => `<tr><td class="num">#${i.id}</td><td class="num">${hms(i.detected_at)}</td><td>${esc(i.application)}</td><td>${esc(i.type_label)}${i.source === 'experiment' ? ' <span class="muted small">(experiment)</span>' : ''}</td>
      <td><span class="pill ${sev(i.severity)}">${esc(i.severity)}</span></td><td><span class="pill ${sev(i.status)}">${i.status[0] + i.status.slice(1).toLowerCase()}</span></td>
      <td>${esc(i.action || (i.status === 'ACTIVE' ? 'Planning…' : '–'))}</td><td class="num">${dur(i.recovery_seconds)}</td><td><a class="btn sm" href="#/incidents/${i.id}">View</a></td></tr>`).join('')
      || '<tr><td colspan="9" class="empty">No incidents. Run an experiment to create one.</td></tr>';
  },
  async detail(id) {
    const r = await api('/api/incidents/' + id);
    if (!r.ok) { $('#main').innerHTML = head('Incident not found', '') + `<a href="#/incidents">Back to incidents</a>`; return; }
    const i = r.data, live = i.status === 'ACTIVE', now = i.live;
    const metrics = (m, liveNow) => {
      const x = liveNow ? {cpu_pct: now?.cpu_pct, mem_pct: now?.mem_pct, resp_ms: now?.resp_ms, err_pct: now?.err_pct} : (m || {});
      const row = (l, v, txt, w, cls) => `<div class="metric-row"><span>${l}</span>${bar(w, cls)}<b>${txt}</b></div>`;
      const cls = (v, hi) => v == null ? '' : v >= hi ? 'critical' : v >= hi * .75 ? 'warning' : 'blue';
      return row('CPU Usage', x.cpu_pct, pct(x.cpu_pct), x.cpu_pct, cls(x.cpu_pct, 90)) + row('Memory Usage', x.mem_pct, pct(x.mem_pct), x.mem_pct, cls(x.mem_pct, 90)) +
        row('Response Time', x.resp_ms, x.resp_ms == null ? '–' : num(x.resp_ms) + 'ms', (x.resp_ms || 0) / 10, cls(x.resp_ms, 1000)) + row('Error Rate', x.err_pct, pct(x.err_pct, 1), (x.err_pct || 0) * 10, cls(x.err_pct, 5));
    };
    const stepsHtml = i.steps.map((s, n) => {
      const inner = s.state === 'done' ? ico('check') : s.state === 'failed' ? ico('x') : n + 1;
      return `<li><span class="sdot ${s.state}">${inner}</span><div><b>${esc(s.label)}</b>${s.detail ? `<div class="d">${esc(s.detail)}${s.state === 'active' ? ' …' : ''}</div>` : ''}</div><span class="t">${hms(s.ts)}</span></li>`;
    }).join('');
    const afterTitle = live ? 'Metrics After Recovery (Live)' : i.status === 'RECOVERED' ? 'Metrics After Recovery' : 'Metrics At End Of Attempt';
    const html = head(`<span class="back"><a href="#/incidents" aria-label="Back to incidents">${ico('back')}</a>Incident #${i.id}</span>`, '', `<span class="pill ${sev(i.status)}">${i.status[0] + i.status.slice(1).toLowerCase()}</span>`) + `
      <div class="split">
        <div class="card"><h2>Incident Information</h2><div class="kv">
          <div>Application</div><div><b>${esc(i.application)}</b></div><div>Incident Type</div><div>${esc(i.type_label)}</div>
          <div>Severity</div><div><span class="pill ${sev(i.severity)}">${esc(i.severity)}</span></div>
          <div>Detected Time</div><div>${new Date(i.detected_at * 1000).toLocaleString([], {hour12: false})}</div>
          <div>Status</div><div><span class="pill ${sev(i.status)}">${i.status[0] + i.status.slice(1).toLowerCase()}</span></div>
          <div>Recovery Action</div><div>${esc(i.action || 'Planning…')}</div><div>Recovery Time</div><div>${dur(i.recovery_seconds)}</div>
          <div>Description</div><div style="white-space:normal">${esc(i.description)}</div></div></div>
        <div class="card"><h2>Recovery Progress</h2><ul class="steps">${stepsHtml}</ul></div>
      </div>
      <div class="split mt"><div class="card"><h2>Metrics Before Incident</h2>${metrics(i.before)}</div>
        <div class="card"><h2>${afterTitle}</h2>${metrics(i.after, live && now)}</div></div>`;
    $('#main').innerHTML = html;
  }
};

V.experiments = {
  render() {
    const names = (S.ov?.apps || []).map(a => a.name);
    const exp = (cls, icon, title, text, kind, btn) => `<div class="exp ${cls}">${ico(icon)}<h3>${title}</h3><p>${text}</p><button class="btn" data-k="${kind}">${btn}</button></div>`;
    $('#main').innerHTML = head('Experiments', 'Trigger test scenarios to demonstrate KubeGuard\'s auto-recovery capability') + `
      <div class="opts"><label>Target application <select id="xapp">${names.map(n => `<option ${n === 'backend' ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
        <label>Duration <select id="xsec"><option value="60">60 s</option><option value="90" selected>90 s</option><option value="120">120 s</option><option value="180">180 s</option></select></label>
        <button class="btn ghost sm" id="xstop">Stop all experiments</button></div>
      <div class="grid g4">
        ${exp('red', 'trash', 'Crash Pod', 'Delete a running pod to simulate pod failure', 'crash', 'Trigger Crash')}
        ${exp('orange', 'cpu', 'CPU Stress', 'Generate high CPU load on application pods', 'cpu', 'Trigger CPU Stress')}
        ${exp('purple', 'db', 'Memory Stress', 'Generate high memory usage on application pods', 'memory', 'Trigger Memory Stress')}
        ${exp('blue', 'tri', 'Generate Errors', 'Make application pods return HTTP 500 to increase error rate', 'errors', 'Trigger Errors')}
      </div>
      <div class="note mt"><b>Experiment Instructions</b><ul>
        <li>Each experiment injects a real failure into the selected application (not a simulated incident row).</li>
        <li>KubeGuard detects the problem from live metrics (it must persist for the sustained time in Settings) and applies recovery.</li>
        <li>Open <a href="#/incidents">Incidents</a> to watch detection, recovery and verification. Crash Pod opens its incident immediately.</li></ul></div>`;
    document.querySelectorAll('[data-k]').forEach(b => b.onclick = async () => {
      b.disabled = true;
      const r = await post('/api/experiments/' + b.dataset.k, {application: $('#xapp').value, seconds: +$('#xsec').value});
      toast(r.ok ? r.data.message : (r.data.message || 'Experiment failed'));
      setTimeout(() => b.disabled = false, 2000);
      if (r.ok && r.data.incident) location.hash = '#/incidents/' + r.data.incident;
    });
    $('#xstop').onclick = async () => { const r = await post('/api/experiments/stop', {application: $('#xapp').value}); toast(r.ok ? `Stopped experiments on ${r.data.pods} pod(s)` : r.data.message); };
  },
  refresh() {}
};

V.metrics = {
  render() {
    const o = S.ov; if (!o) return;
    const app = S.route.param || o.apps[0]?.name;
    $('#main').innerHTML = head(`<span class="back"><a href="#/applications" aria-label="Back to applications">${ico('back')}</a>Application Metrics - ${esc(app || '')}</span>`, '',
      `<select id="msel" aria-label="Application">${o.apps.map(a => `<option ${a.name === app ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select>
       <select id="mrange" aria-label="Time range">${[['15m', 'Last 15 minutes'], ['1h', 'Last 1 hour'], ['3h', 'Last 3 hours'], ['6h', 'Last 6 hours']].map(([v, l]) => `<option value="${v}" ${S.range === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
       <button class="btn ghost sm" id="mstop">Stop monitoring</button>`) +
      `<div class="grid g2" id="mcharts"></div>`;
    $('#msel').onchange = e => location.hash = '#/metrics/' + encodeURIComponent(e.target.value);
    $('#mrange').onchange = e => { S.range = e.target.value; this.refresh(true); };
    $('#mstop').onclick = async () => { if (!app || !confirm(`Stop monitoring ${app}? Its deployment is not changed.`)) return; const r = await api('/api/apps/' + encodeURIComponent(app), {method: 'DELETE'}); toast(r.ok ? app + ' is no longer monitored' : r.data.message); location.hash = '#/applications'; };
    this.refresh(true);
  },
  async refresh(force) {
    const app = S.route.param || S.ov?.apps[0]?.name; if (!app || !$('#mcharts')) return;
    if (!force && Date.now() - (this.at || 0) < 10000) return;
    this.at = Date.now();
    const r = await api(`/api/metrics/app/${encodeURIComponent(app)}?range=${S.range}`); if (!r.ok || !$('#mcharts')) return;
    const d = r.data, card = (t, s, opt, color) => `<div class="card"><h2>${t}</h2><div class="chart">${lineChart([{name: t, color, points: s}], {...opt, fill: true})}</div></div>`;
    $('#mcharts').innerHTML = card('CPU Usage (%)', d.cpu, {max: 100}, '#1769e0') + card('Memory Usage (%)', d.memory, {max: 100}, '#12a05c') +
      card('Response Time (ms)', d.response, {}, '#7a3de0') + card('Error Rate (%)', d.errors, {}, '#dc3a3a');
  }
};

V.settings = {
  fields: [['sustain_seconds', 'Sustained duration', 'seconds a breach must last before an incident is raised', 's'],
    ['cpu_critical', 'CPU critical threshold', '% of the pod CPU limit', '%'], ['memory_critical', 'Memory critical threshold', '% of the pod memory limit', '%'],
    ['error_rate_critical', 'Error-rate threshold', '% of requests answered with HTTP 5xx', '%'], ['latency_warn_ms', 'Latency warning', 'only lowers the health score', 'ms'],
    ['max_replicas', 'Maximum replicas', 'upper bound for automatic scale-out', ''], ['cooldown_seconds', 'Cooldown', 'minimum time between incidents of the same type', 's'],
    ['verify_timeout', 'Verification timeout', 'mark recovery as failed after this long', 's'], ['self_heal_grace', 'Self-heal grace', 'time Kubernetes gets to replace a failed pod first', 's'],
    ['scale_down_idle_seconds', 'Scale-down delay', 'low load for this long returns to the baseline replica count', 's']],
  async render() {
    const r = await api('/api/settings'); S.settings = r.data;
    $('#main').innerHTML = head('Settings', 'Detection thresholds and auto-recovery policy') + `<div class="card" style="max-width:760px">
      <div class="set-row"><div><b>Auto-recovery</b><div class="muted small">When off, KubeGuard still detects and records incidents but takes no action.</div></div>
        <button class="switch" id="auto" role="switch" aria-checked="${!!S.settings.auto_recovery}" aria-label="Auto-recovery"></button></div>
      ${this.fields.map(([k, l, h, u]) => `<div class="set-row"><div><b>${l}</b><div class="muted small">${h}</div></div><label><input type="number" id="s_${k}" value="${S.settings[k]}" step="any"> ${u}</label></div>`).join('')}
      <div style="margin-top:16px"><button class="btn" id="save">Save settings</button></div></div>`;
    $('#auto').onclick = e => e.currentTarget.setAttribute('aria-checked', e.currentTarget.getAttribute('aria-checked') !== 'true');
    $('#save').onclick = async () => {
      const body = {auto_recovery: $('#auto').getAttribute('aria-checked') === 'true' ? 1 : 0};
      this.fields.forEach(([k]) => body[k] = parseFloat($('#s_' + k).value));
      const res = await post('/api/settings', body); toast(res.ok ? 'Settings saved' : (res.data.error || 'Could not save settings'));
      if (res.ok) this.render();
    };
  },
  refresh() {}
};

/* --------------------------------------------------------------- router */
function parseRoute() {
  const [path, qs] = location.hash.replace(/^#\/?/, '').split('?');
  const [name, param] = path.split('/');
  return {name: V[name] ? name : 'dashboard', param: param ? decodeURIComponent(param) : '', query: Object.fromEntries(new URLSearchParams(qs || ''))};
}

function route() {
  S.route = parseRoute();
  $('#nav').innerHTML = NAV.map(([k, l, i]) => `<a href="#/${k}" class="${S.route.name === k ? 'active' : ''}" ${S.route.name === k ? 'aria-current="page"' : ''}>${ico(i)}<span>${l}</span></a>`).join('');
  V[S.route.name].render();
}

async function tick() {
  const r = await api('/api/overview');
  if (r.ok) S.ov = r.data;
  const v = V[S.route.name];
  if (S.ov && v.refresh) v.refresh();
}

(async function init() {
  const c = await api('/api/config'); S.cfg = c.data;
  $('#brand').textContent = S.cfg.brand || 'KubeGuard'; document.title = S.cfg.brand || 'KubeGuard';
  $('#mode').textContent = S.cfg.mode === 'mock' ? 'Simulator mode' : `ns: ${S.cfg.namespace}`;
  const r = await api('/api/overview'); if (r.ok) S.ov = r.data;
  window.addEventListener('hashchange', route);
  route();
  setInterval(tick, 3000);
})();
