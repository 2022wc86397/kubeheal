import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.db import Store            # noqa: E402
from app.experiments import Experiments   # noqa: E402
from app.mock import MockWorld      # noqa: E402
from app.monitor import Monitor     # noqa: E402
from app.recovery import Recovery   # noqa: E402


class Rt:
    """Fast test runtime: simulated cluster with sub-second timings."""
    def __init__(self, tmp_path):
        self.world = MockWorld(startup=0.4, seed=1, seed_history=False)
        self.cluster = self.metrics = self.world
        self.store = Store(str(tmp_path / "t.db"))
        self.store.save_settings({"sustain_seconds": 0, "cooldown_seconds": 0, "verify_timeout": 30,
                                  "self_heal_grace": 2, "scale_down_idle_seconds": 10})
        self.recovery = Recovery(self.world, self.world, self.store, poll=0.2)
        self.monitor = Monitor(self.world, self.world, self.store, self.recovery, interval=0.2)
        self.experiments = Experiments(self.world, self.recovery, self.world.apply_chaos)

    def wait(self, cond, timeout=25, step=0.2):
        end = time.time() + timeout
        while time.time() < end:
            self.monitor.tick()
            if cond():
                return True
            time.sleep(step)
        return False

    def incident_for(self, typ):
        return next((i for i in self.store.list_incidents() if i["type"] == typ), None)


@pytest.fixture
def rt(tmp_path):
    return Rt(tmp_path)
