"""Runtime configuration (all values come from environment variables)."""
import os


def _float(name, default):
    return float(os.getenv(name, default))


class Config:
    def __init__(self):
        self.mode = os.getenv("KUBEHEAL_MODE", "cluster")          # cluster | mock
        self.namespace = os.getenv("WATCH_NAMESPACE", "kubeheal-demo")
        self.prometheus_url = os.getenv(
            "PROMETHEUS_URL", "http://prometheus.monitoring.svc.cluster.local:9090")
        self.db_path = os.getenv("DB_PATH", "/data/kubeheal.db")
        self.interval = _float("DETECT_INTERVAL_SECONDS", 10)
        self.verify_poll = _float("VERIFY_POLL_SECONDS", 3)
        self.chaos_port = int(os.getenv("CHAOS_PORT", "8080"))
        self.brand = os.getenv("BRAND_NAME", "KubeGuard")
        self.auth_user = os.getenv("AUTH_USER", "admin")
        self.auth_password = os.getenv("AUTH_PASSWORD", "")        # empty = auth disabled
        self.mock_startup = _float("MOCK_STARTUP_SECONDS", 4)
