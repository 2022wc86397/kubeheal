#!/usr/bin/env bash
# Run the dashboard against the built-in cluster simulator (no Kubernetes needed). http://localhost:8080
set -euo pipefail
cd "$(dirname "$0")/../services/kubeheal"
[[ -d .venv ]] || python3 -m venv .venv
. .venv/bin/activate
pip install -q Flask==3.1.2 requests==2.32.5
export KUBEHEAL_MODE=mock DB_PATH="${DB_PATH:-/tmp/kubeheal-mock.db}" DETECT_INTERVAL_SECONDS=3 VERIFY_POLL_SECONDS=1 MOCK_STARTUP_SECONDS=3
echo "Simulator mode: open http://localhost:8080 and try the Experiments page"
python -c "from app.main import create_app; create_app().run(host='127.0.0.1', port=8080, threaded=True)"
